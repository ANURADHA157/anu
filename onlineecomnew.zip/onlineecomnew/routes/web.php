<?php

use App\Http\Controllers\HomeController;
use App\Http\Controllers\datacontroller;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    // return view('welcome');
    return redirect('managetest');
});

Route::get('home', [HomeController::class, 'index']);
Route::get('myquestionnaire', [HomeController::class, 'sit']);
Route::get('editquestionnaire', [HomeController::class, 'dom']);
Route::get('addquestionnaire', [HomeController::class, 'min']);

Route::post('showData', [HomeController::class, 'showData']);
Route::get('managetest', [HomeController::class, 'mon']);
Route::post('storeData', [HomeController::class, 'storeData']);
Route::post('Data', [HomeController::class, 'Data']);
Route::post('product', [datacontroller::class, 'product']);
Route::get('insert', [HomeController::class, 'insert']);
Route::get('ckeck', [questioncontroller::class, 'check']);
Route::get('stream', [datacontroller::class, 'stream']);
Route::post('getfunction2', [datacontroller::class, 'stream']);
