
    <div class="navbar navbar-inverse navbar-fixed-top" role="navigation">
        <div class="container-fluid">
            <div class="navbar-header navbar-right">
                <div class="hidden-lg pull-right">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbar-right">
                        <span class="sr-only">Toggle navigation</span>
                        <i class="fa fa-chevron-down"></i>
                    </button>

                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".sidebar">
                        <span class="sr-only">Toggle sidebar</span>
                        <i class="fa fa-bars"></i>
                    </button>
                </div>

                <ul class="nav navbar-nav navbar-left-custom ">
					 <li><a class="nav-icon sidebar-toggle"><i class="fa fa-bars"></i></a></li>
                    <li class="user dropdown">
                        <a class="dropdown-toggle" data-toggle="dropdown">

                            <i class="caret"></i>
                        </a>
                        <ul class="dropdown-menu">

                        </ul>
                    </li>

                </ul>
            </div>

        </div>
    </div>
    <!-- /navbar -->

<!-- Navbar -->

