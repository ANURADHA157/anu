<ul class="navigation">
    <li class="active"><a href="admin"><i class="fa fa-laptop"></i>Dashboard</a></li>
    <li>
        <a href="#" class="expand"><i class="fa fa-user"></i>Profile Info</a>
        <ul>
            <li><a href="employer/companyprofile.php">Company Profile</a></li>
            <li><a href="employer/mydetails.php">My Details</a></li>
            <li><a href="employer/mysocial.php">My Social</a></li>
            <li><a href="employer/changepassword.php">Change Password</a></li>
        </ul>
    </li>
    <li>
        <a href="#" class="expand"><i class="fa fa-building-o"></i>Jobs</a>
        <ul>
            <li><a href="employer/myjobs.php">All Jobs</a></li>
            <li><a href="{{url('/')}}admin.addjob">Add Job</a></li>
            <!-- <li><a href="employer/myquestionnaire.php">Questionnaire</a></li> -->

            <li><a href="{{url('/')}}/myquestionnaire">Questionnaire</a></li>




















        </ul>
    </li>

    <li><a href="property/rooms"><i class="fa fa-users"></i>My Applicants</a></li>
    <li>
        <a href="#" class="expand"><i class="fa fa-calendar"></i>Interview Calendar</a>

    </li>
    <li><a href="property/getcode"><i class="fa fa-qrcode"></i>Analytics</a></li>
    <li><a href="property/getcode">₹</i>My Orders</a></li>
    <!--<li ><a href="property/messages"><i class="fa fa-envelope"></i>Messages</a></li>-->
</ul>