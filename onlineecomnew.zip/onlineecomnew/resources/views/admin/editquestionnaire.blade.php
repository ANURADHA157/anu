<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>CareersatCore</title>
    @include('admin/include/header')
    <link rel="stylesheet" type="text/css" href="../assets/plugins/select2/select2_metro.css" />
    <link rel="stylesheet" type="text/css" href="//cdn.datatables.net/1.10.11/css/jquery.dataTables.min.css">
    <!--<script type="text/javascript" src="assets/js/charts/simple_graph.js"></script>-->
</head>




@if(Session::has('msg'))
<p class="alart alat-success">{{Session::get('msg') }}</p>
@endif


<body>


    <div class="container-fluid">
        <div class="page-header">
            <div class="logo"><a href="index.html" title=""><img src="{{ asset('assets/img/landinglogo.png')}}" style="width:225px;" alt=""></a></div>
            <ul class="middle-nav">
                <li><a href="#" class="btn btn-danger"><i class="fa fa-comments-o"></i> <span>Interviews</span></a>
                    <div class="label label-danger">0</div>
                </li>
                <li><a href="#" class="btn btn-success"><i class="fa fa-bars"></i> <span>Analytics</span></a></li>
                <li><a href="#" class="btn btn-info"><i class="fa fa-male"></i> <span>Applicants</span></a></li>
            </ul>
        </div>
    </div>
    <!-- /page header -->
    <!-- Page container -->
    <div class="page-container container-fluid">
        <!-- Sidebar -->
        <div class="sidebar collapse">
            @include('admin/include/sidebar')
        </div>




        <!-- /////created successfully/////// -->










        <div class="page-content">
            <div class="page-title">
                <h5><i class="fa fa-bars"></i>Edit Questionnaire</h5>
            </div>
            <!-- /page title -->
            <!-- /page title -->
            <div class="panel panel-default">
                <div class="panel-heading">
                    <h6 class="panel-title">
                        <?php if (isset($_GET['ref'])) { ?><a class="btn btn-info pull-right job-right" href="<?php echo $_GET['ref']; ?>"><?php } else { ?><a class="btn btn-info  pull-right job-right  " href="myquestionnaire.php"><?php } ?><i class="fa fa-times " style="font-size:16px;"></i>
                                CLOSE SHEET</a>
                    </h6>
                </div>

                <div class="clearfix"></div>

                <!-- End .title -->
                <div class="panel-body" style="padding-top:0px;padding-bottom:0px">

                    <div>


                        <form class="custom_form" id="" method="get" action="{{url('insert')}}" autocomplete="off">
                            @csrf
                            <input type="hidden" value="" name="jobid">

                            <div class="form-container form-group">
                                <label class="control-label col-md-3">Name</label>
                                <div class="col-md-9">
                                    <input id="cname" name="name" type="text" required class="form-control field1 form-field-name" value="" />
                                </div>
                            </div>
                            <div class="clearfix"></div><br>
                            <div class="form-container  form-group">
                                <label class="control-label col-md-3">Description</label>
                                <div class="col-md-9">
                                    <input id="cname" name="description" type="text" required class="form-control field1 form-field-name" value="" />
                                </div>
                            </div>
                            <div class="clearfix"></div><br>
                            <div class="form-actions row-fluid">
                                <div class="span7 offset3">
                                    <!-- <button type="submit" class="btn btn-info" name='Submit' value='Update'>Save changes</button> -->

                                    <button class="btn btn-info alt_btn" type="submit">Save changes</button>


                                </div>
                            </div>

                            <!-- Gets replaced with TinyMCE, remember HTML in a textarea should be encoded -->

                        </form>
                        <div style="clear:both"></div>
                    </div>

                </div>
            </div>

        </div>

    </div>


    <script type="text/javascript" language="javascript" src="js/jquery-1.8.2.min.js"></script>
    <script src="js/jquery.stepy.min.js"></script>
    <script type="text/javascript" src="assets/plugins/bootstrap-fileupload/bootstrap-fileupload.js"></script>
    <script type="text/javascript" src="assets/plugins/select2/select2.min.js"></script>
    <script type="text/javascript" src="assets/plugins/jquery-tags-input/jquery.tagsinput.min.js"></script>
    <script type="text/javascript" src="assets/plugins/tinymce/jscripts/tiny_mce/tiny_mce.js"></script>

    <script>
        $(document).ready(function() {
            $("#navigation ul li a").removeClass("active");
            $("#navigation ul li a#question").addClass("active");
            $(".inner-left.sidenav a").removeClass("active");
            $(".inner-left.sidenav a#aboutus").addClass("active");



        });

        function confirmChoice(j) {
            msgQuestion = "Confirm Delete!";
            userResponse = confirm(msgQuestion);
            if (userResponse == 1) {
                location = "myjobs.php?del=del&co=" + j;
            } else {
                return;
            }
        }
    </script>
    <!-- javascript at the bottom for fast page loading -->


</body>

</html>