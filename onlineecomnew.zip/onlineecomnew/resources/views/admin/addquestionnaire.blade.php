<!DOCTYPE HTML>

</div>




<center>
    <div class="links">
        <br><br><i><a href="<?php echo url('managetest') ?>">Click here</a></i>
</center>





<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width; initial-scale=1.0; maximum-scale=1.0; user-scalable=0;" />
<meta name="format-detection" content="telephone=no" />
<title>CORE</title>
<link href="../css/style.css" type="text/css" rel="stylesheet" />
<link href="../css/meanmenu.css" type="text/css" rel="stylesheet" />
<link href="css/font-awesome.css" type="text/css" rel="stylesheet" />
<link href="css/animations.css" type="text/css" rel="stylesheet" />

<link href='https://fonts.googleapis.com/css?family=Source+Sans+Pro:400,300,300italic,600,700' rel='stylesheet' type='text/css'>
<link href='https://cdnjs.cloudflare.com/ajax/libs/fancybox/2.1.5/jquery.fancybox.css' rel='stylesheet' type='text/css'>
<link rel="stylesheet" type="text/css" href="//cdn.datatables.net/responsive/1.0.0/css/dataTables.responsive.css">

<!--[if lt IE 9]>
	<link rel="stylesheet" type="text/css" href="css/ie8-and-down.css" />
<![endif]-->
<script type="text/javascript" src="js/jquery-1.11.0.min.js"></script>
<script type="text/javascript" language="javascript" src="https://cdn.datatables.net/1.10.8/js/jquery.dataTables.min.js"></script>
<script>
    $(document).ready(function() {
        $('#example').DataTable();
    });
</script>
</head>
<style>
    a.post_job {
        background: #476B9E;
        color: #fff;
        padding: 10px 15px;
    }

    a.post_job:hover {
        color: #fff;
    }

    .no-bg td {
        background: none !important;
    }

    .display tr td {
        background: #5D8CA5;
        /* border: 1px solid #666; */
        border-radius: 5px;
        /* padding: 10px; */
        border-bottom-left-radius: 0px;
        border-bottom-right-radius: 0px;
    }

    .salary_range {
        background: none !important;
        ;
        padding: 0px !important;
    }

    .job_container {
        margin-top: 30px;
        background: #fafafa;
        padding: 20px;
        border: 1px solid #ccc;
        border-top: 0px;
        margin-bottom: 0px !important;
    }

    .key_videos {
        padding: 10px 20px;
        background: #848484;
        padding: 10px 20px;
        color: #fff;
    }

    .key_videos a,
    .key_videos a:hover {
        color: #fff;
    }
</style>
<html>
<?php define('BASE_URL', 'https://careersatcore.com/corenew/'); ?>
<style>
    .select2-search-choice-close {
        display: none !important;
    }

    label {
        line-height: 30px;
    }
</style>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>CareersatCore</title>
    @include('admin/include/header')
    <link rel="stylesheet" type="text/css" href="../assets/plugins/select2/select2_metro.css" />
    <link rel="stylesheet" type="text/css" href="//cdn.datatables.net/1.10.11/css/jquery.dataTables.min.css">
    <!--<script type="text/javascript" src="<?php echo BASE_URL; ?>assets/js/charts/simple_graph.js"></script>-->
</head>

<body>
    <!-- Navbar -->

    @include('admin/include/navigation')
    <!-- /navbar -->
    <!-- Page header -->
    <div class="container-fluid">
        <div class="page-header">
            <div class="logo"><a href="index.html" title=""><img src="{{ asset('assets/img/landinglogo.png')}}" style="width:225px;" alt=""></a></div>
            <ul class="middle-nav">
                <li><a href="#" class="btn btn-danger"><i class="fa fa-comments-o"></i> <span>Interviews</span></a>
                    <div class="label label-danger">0</div>
                </li>
                <li><a href="#" class="btn btn-success"><i class="fa fa-bars"></i> <span>Analytics</span></a></li>
                <li><a href="#" class="btn btn-info"><i class="fa fa-male"></i> <span>Applicants</span></a></li>
            </ul>
        </div>
    </div>
    <!-- /page header -->
    <!-- Page container -->
    <div class="page-container container-fluid">
        <!-- Sidebar -->
        <div class="sidebar collapse">
            @include('admin/include/sidebar')
        </div>
        <div class="page-content">
            <div class="page-title">
                <h5><i class="fa fa-bars"></i>Add Quesionnaire</h5>
            </div>
            <!-- /page title -->
            <!-- /page title -->
            <div class="panel panel-default">

                @if(Session::has('msg'))
                <p class="alart alat-success">{{Session::get('msg') }}</p>
                @endif
                <form class="custom_form" id="" method="get" action="" autocomplete="off">


                    @csrf


                    <!-- s -->
                    <div class="form-container">
                        <label class="uname span3">Name<span class="help-block"></span> </label>
                        <div class="clearfix"></div>
                        <div class="span10">
                            <!-- <input id="cname" name="name" type="text" required class="field1 form-field-name" value="" cols="50" rows="4" /> -->
                            <textarea name="name" id="cname" cols="60" rows="2" required></textarea>
                        </div>
                    </div><br><br>
                    <div class="clearfix"></div>
                    <!-- <div class="form-container"> -->
                    <label class="uname span3">Description<span class="help-block"></span> </label>
                    <div class="clearfix"></div>
                    <div class="span10">
                        <!-- <input id="cname" name="description" type="text" required class="field1 form-field-name" value="" />
                    </div> -->

                    </div>
                    <textarea name="description" id="cname" cols="80" rows="4" required></textarea>
                    <!-- <textarea rows="4" cols="50" name="comment" required> -->
                    <div class="form-actions row-fluid">
                        <div class="span7 offset3">


                            <!-- <button type="submit" class="alt_btn read_red" style='color:#fff;background:#e8645a;padding:10px 15px;text-decoration:none;' name='Submit' value='Submit'>Save changes</button> -->
                            <button class="btn btn-info alt_btn" type="submit">Save changes</button>
                        </div>
                    </div>

                    <!-- Gets replaced with TinyMCE, remember HTML in a textarea should be encoded -->

                </form>
                <div style="clear:both"></div>
            </div>

        </div>

    </div>



    <script type="text/javascript" language="javascript" src="js/jquery-1.8.2.min.js"></script>


    <script>
        $(document).ready(function() {
            $("#navigation ul li a").removeClass("active");
            $("#navigation ul li a#question").addClass("active");
            $(".inner-left.sidenav a").removeClass("active");
            $(".inner-left.sidenav a#aboutus").addClass("active");



        });

        function confirmChoice(j) {
            msgQuestion = "Confirm Delete!";
            userResponse = confirm(msgQuestion);
            if (userResponse == 1) {
                location = "myjobs.php?del=del&co=" + j;
            } else {
                return;
            }
        }
    </script>
    <!-- javascript at the bottom for fast page loading -->


</body>

</html>