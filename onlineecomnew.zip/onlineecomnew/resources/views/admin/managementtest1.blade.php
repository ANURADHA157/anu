<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>CareersatCore</title>
    @include('admin/include/header')


    <!--<script type="text/javascript" src="assets/js/charts/simple_graph.js"></script>-->
</head>

<body>
    <!-- Navbar -->

    @include('admin/include/navigation')
    <!-- /navbar -->
    <!-- Page header -->





    @if(Session::has('msg'))
    <p class="alert alert-success">{{Session::get('msg')}}</p>
    @endif






    <!-- 
    ?> -->
    <script>
        function check() {
            var strErr, field;
            strErr = "";
            if (document.form1.catname.value == "") {
                strErr += "*Enter Category Name \n";
                if (typeof(field) == "undefined") {
                    field = document.form1.catname;
                }
            }
            if (strErr != "") {
                alert("The required Information is incomplete\n\n" + strErr);
                field.focus();
                return false;
            }
        }
    </script>
    <script>
        function confirmChoice(j) {
            msgQuestion = "Confirm Delete!";
            userResponse = confirm(msgQuestion);
            if (userResponse == 1) {
                location = "managetest?del=del&co=" + j;
            } else {
                return;
            }
        }
    </script>

    <div class="container-fluid">
        <div class="page-header">
            <div class="logo"><a href="index.html" title=""><img src="{{ asset('assets/img/landinglogo.png')}}" style="width:225px;" alt=""></a></div>
            <ul class="middle-nav">
                <li><a href="#" class="btn btn-danger"><i class="fa fa-comments-o"></i> <span>Interviews</span></a>
                    <div class="label label-danger">0</div>
                </li>
                <li><a href="#" class="btn btn-success"><i class="fa fa-bars"></i> <span>Analytics</span></a></li>
                <li><a href="#" class="btn btn-info"><i class="fa fa-male"></i> <span>Applicants</span></a></li>
            </ul>
        </div>
    </div>
    <!-- /page header -->
    <!-- Page container -->
    <div class="page-container container-fluid">
        <!-- Sidebar -->
        <div class="sidebar collapse">
            @include('admin/include/sidebar')
        </div>

        <div class="page-content">
            <div class="page-title">
                <h5><i class="fa fa-bars"></i>Edit Questionnaire</h5>
            </div>
            <!-- /page title -->
            <!-- /page title -->
            <div class="panel panel-default">
                <div class="panel-heading">
                    <h6 class="panel-title">
                        <?php if (isset($_GET['ref'])) { ?><a class="btn btn-info pull-right job-right" href="<?php echo $_GET['ref']; ?>"><?php } else { ?><a class="btn btn-info  pull-right job-right  " href="{{url('/')}}/myquestionnaire"><?php } ?><i class="fa fa-times " style="font-size:16px;"></i>
                                CLOSE SHEET</a>
                    </h6>
                </div>

                <div class="clearfix"></div>

                <!-- End .title -->
                <div class="panel-body" style="padding-top:0px;padding-bottom:0px">

                    <form class="form-horizontal" method="post" action="" autocomplete="off">
                        @csrf
                        <input type="hidden" id="testid" value="">
                        <div id="current_questions">


                        </div>

                        <div class="form-container">
                            <label class="uname span3"><span class="help-block"></span>Question </label>
                            <div class="clearfix"></div>
                            <div class="controls span8">
                                <textarea id="elm3" name="question" rows="100" cols="80" style="width: 100%;border:1px solid #626262!important;height:100px!important;resize:none;" class="clearfieldarea field1 form-field-name"></textarea>
                            </div>
                        </div>
                        <div style="clear:both"></div>
                        <div class="form-container">
                            <label class="uname span3" for="content">Expected Answer Type</label>
                            <div class="clearfix"></div>
                            <div class="controls">
                                <select name="answer" id="answer" class="select" style="width:100%">
                                    <option value="1">Multiple Choice</option>
                                    <option value="2">Yes/ No</option>
                                    <option value="3">Multiple Response</option>
                                    <option value="4">Range</option>
                                    <option value="5">Allowed Choices</option>
                                </select>
                            </div>
                        </div>

                        <div style="clear:both"></div>
                        <div id="choice1" class="choices">
                            <div class="form-container">
                                <label class="uname span3" for="content" style="text-align:left">Enter choices and mark which answer is correct</label>
                                <div class="clearfix"></div>
                            </div>
                            <div class="form-container" id="mcchoices">
                                <div class="radio1">
                                    <label class="radio" style="float:left">
                                        <input type="radio" name="seq" value="cc_1" data-title="" id="cr1" /></label>
                                    <label><input type="text" id="c_1" class="form-control m-wrap clearfield" name="c_1" value="" />
                                    </label>
                                </div>
                                <div class="radio1">
                                    <div style="clear:both"></div>
                                    <label class="radio" style="float:left">
                                        <input type="radio" name="seq" value="cc_2" data-title="" id="cr2" /></label>
                                    <label>
                                        <input type="text" id="is_answer" class="form-control span11 m-wrap clearfield" name="is_answer" value="" />
                                    </label>
                                </div>
                                <div class="radio1">
                                    <div style="clear:both"></div>
                                    <label class="radio" style="float:left">
                                        <input type="radio" name="seq" value="cc_3" data-title="" id="cr3" /></label>
                                    <label>
                                        <input type="text" id="c_3" class="form-control span11 m-wrap clearfield" name="c_3" value="" />
                                    </label>
                                </div>
                                <div class="radio1">
                                    <div style="clear:both"></div>
                                    <label class="radio" style="float:left">
                                        <input type="radio" name="seq" value="cc_4" data-title="" id="cr4" /></label>
                                    <label>
                                        <input type="text" id="c_4" class="form-control span11 m-wrap clearfield" name="c_4" value="" />
                                    </label>
                                </div>
                                <div style="clear:both"></div>
                            </div>
                            <div class="form-container">
                                <label class="control-label" for="content " style="text-align:left;width:300px"><a href="javascript:void(0);" id="addmc">Add</a> / <a href="javascript:void(0);" id="removemc">Remove</a> Answer Choice</label>
                            </div>
                        </div>
                        <div id="choice2" class="choices" style="display:none">
                            <div class="form-container">
                                <label class="uname span3" for="content" style="text-align:left">Mark which answer is correct</label>
                                <div class="clearfix"></div>
                            </div>
                            <div class="form-container">
                                <label class="radio">
                                    <input type="radio" name="tf" value="True" data-title="" id="true" />
                                    Yes
                                </label>
                                <div class="clearfix"></div>
                                <label class="radio">
                                    <input type="radio" name="tf" value="False" id="false" data-title="Desktop Software" checked />
                                    No
                                </label>
                            </div>
                        </div>
                        <div id="choice3" class="choices" style="display:none">
                            <div class="form-container">
                                <label class="uname span3" for="content" style="text-align:left">Enter choices and mark which answer is correct</label>
                                <div class="clearfix"></div>
                            </div>
                            <div class="form-container" id="mrchoices">
                                <div class="check1">
                                    <label class="check" style="float:left">
                                        <input type="checkbox" name="seq1[]" value="rr_1" data-title="" id="rc1" /></label><label>
                                        <input type="text" id="r_1" class="form-control span11 m-wrap clearfield" name="r_1" required="required" value="" />
                                    </label>
                                </div>
                                <div style="clear:both"></div>
                                <div class="check1">
                                    <label class="check" style="float:left">
                                        <input type="checkbox" name="seq1[]" value="rr_2" data-title="" id="rc2" /></label><label>
                                        <input type="text" id="r_2" class="form-control span11 m-wrap clearfield" name="r_2" required="required" value="" />
                                    </label>
                                </div>
                                <div style="clear:both"></div>
                                <div class="check1">
                                    <label class="check" style="float:left">
                                        <input type="checkbox" name="seq1[]" value="rr_3" data-title="" id="rc3" /></label><label>
                                        <input type="text" id="r_3" class="form-control span11 m-wrap clearfield" name="r_3" required="required" value="" />
                                    </label>
                                </div>
                                <div style="clear:both"></div>
                                <div class="check1">
                                    <label class="check" style="float:left">
                                        <input type="checkbox" name="seq1[]" value="rr_4" data-title="" id="rc4" /></label><label>
                                        <input type="text" id="r_4" class="form-control span11 m-wrap clearfield" name="r_4" required="required" value="" />
                                    </label>
                                </div>
                                <div style="clear:both"></div>
                            </div>
                            <div class="form-container">
                                <label class="control-label" for="content " style="text-align:left;width:300px"><a href="javascript:void(0);" id="addmr">Add</a> / <a href="javascript:void(0);" id="removemr">Remove</a> Answer Choice</label>
                            </div>
                        </div>
                        <div id="choice4" class="choices" style="display:none">
                            <div class="form-container">
                                <label class="uname span3" for="content">Enter the range</label>
                                <div class="clearfix"></div>
                            </div>
                            <div class="form-container" id="bchoices">
                                <div class="col-md-3" style="width:350px;margin:0px 10px;">
                                    <input type="text" class="form-control" id="rang_1" name="rang_1" required="required" value="" />
                                </div>
                                <div class="col-md-1"> to</div>
                                <div class="col-md-3" style="width:350px;margin:0px 10px;">
                                    <input type="text" id="rang_2" name="rang_2" required="required" class="form-control" value="" />
                                </div>
                                <div class="clearfix"></div>
                            </div>

                        </div>
                        <div id="choice5" class="choices" style="display:none">
                            <div class="form-container">
                                <label class="uname span3" for="content">Enter the allowed choices</label>
                                <div class="clearfix"></div>
                            </div>
                            <div class="form-container" id="alchoices">
                                <div class="span4">
                                    <input type="hidden" id="al_1" style="width:100%" class="field1 form-field-text" name="al_1" value="">
                                </div>

                                <div class="clearfix"></div>
                            </div>

                        </div>

                        <div style="clear:both"></div>
                        <div class="form-container">
                            <label class="control-label col-md-3">Points</label>
                            <div class="col-md-3">
                                <input type="text" id="points" class="form-control span m-wrap clearfield" name="points" value="" required="required" />
                            </div>
                        </div>
                        <div class="form-container">
                            <a href="<?php echo url('managetest') ?>" class="btn btn-info alt_btn read_red savequestion" id='addquestion' style="text-decoration:none;">
                                <i class=""></i>Submit
                            </a>
                            <!-- <button class="btn btn-info alt_btn" type="submit">Submit</button> -->
                        </div>
                        <div style="clear:both"></div>


                    </form>

                </div>
            </div>


            <script type="text/javascript">
                /**** Specific JS for this page ****/
                // Datatables
                $(document).ready(function() {

                    $(".questtitle1").click(function() {
                        $(".newquest").show();
                        $(".questtitle").show();
                        $(".questtitle1").hide();
                        $("#addquestion").show();
                    });
                    $("#q_type").change(function() {
                        question_type = $(this).find("option:selected").val();

                        $(".choices").hide();
                        $("#choice" + question_type).show();

                    });

                });

                $("#addmc").click(function() {
                    if ($("#mcchoices").find("div[class='radio1']").length < 6) {
                        var no = $("#mcchoices").find("div[class='radio1']").length + 1;
                        $("#mcchoices").append('<div class="radio1"><label class="radio" style="float:left"><span><input type="radio" name="seq" value="cc_' + no + '" data-title="" id="cr' + no + '"></span></label><label><input type="text" id="c_' + no + '" class="form-control span11 m-wrap" name="c_' + no + '" required="required" value=""></label></div><div style="clear:both"></div>');
                    } else {
                        alert("Multiple Choices can have maximum 6 choices");
                    }
                });
                $("#addmr").click(function() {
                    if ($("#mrchoices").find("div[class='check1']").length < 6) {
                        var no = $("#mrchoices").find("label[class='check']").length + 1;
                        $("#mrchoices").append('<div class="check1"><label class="check" style="float:left"><span><input type="checkbox" name="seq1[]" value="rr_" data-title=""></span></label><label><input type="text" id="r_' + no + '" class="form-control span11 m-wrap" name="r_' + no + '" required="required" value=""></label></div><div style="clear:both"></div>');

                    } else {
                        alert("Multiple Responses can have maximum 6 choices");
                    }
                });

                $("#removemr").click(function() {
                    if ($("#mrchoices").find("div[class='check1']").length > 2) {
                        $("#mrchoices").find("div[class='check1']").last().remove();
                    } else {
                        alert("Multiple Choices should have minimum 2 choices");
                    }
                });

                $("#removemc").click(function() {
                    if ($("#mcchoices").find("div[class='radio1']").length > 2) {
                        $("#mcchoices").find("div[class='radio1']").last().remove();
                    } else {
                        alert("Multiple Choices should have minimum 2 choices");
                    }
                });

                $('body').on("click", ".deletetest", function() {
                    deletequest($(this).data("id"));
                });

                function deletequest(id) {
                    msgQuestion = "Confirm Delete!";
                    userResponse = confirm(msgQuestion);
                    if (userResponse == 1) {
                        jQuery.ajax({
                            url: 'deletequestion.php',
                            type: 'POST',
                            data: {
                                'action': 'sendmessage',
                                'questid': id
                            },
                            dataType: 'JSON',
                            success: function(data2) {
                                var testid = $("#testid").val();
                                $.get('gettest.php?testid=' + testid, function(data3) {
                                    $("#current_questions").html(data3);
                                });

                            },
                            error: function(errorThrown) {
                                console.log(errorThrown);
                            }
                        });
                    } else {
                        return;
                    }
                }

                $("#addquestion").click(function() {

                    question_type = $("#q_type").find("option:selected").html();
                    $.ajax({
                        url: 'gettotal.php',
                        type: 'POST',
                        data: {
                            'action': 'addquestion',
                            'testid': $("#testid").val(),
                        },
                        success: function(data) {

                            currtotal = parseInt(data) + parseInt(jQuery("#points").val());

                            if (data <= 100 && currtotal < 101) {
                                addquestion();
                            } else {
                                alert("Total Points cannot be more than 100");
                            }

                        },
                        error: function(errorThrown) {
                            console.log(errorThrown);
                        }
                    });
                });

                function addquestion() {
                    question_type = $("#q_type").find("option:selected").html();
                    jQuery.ajax({
                        url: 'addquestion.php',
                        type: 'POST',
                        data: {
                            'action': 'addquestion',
                            'question': jQuery("#elm3").val(),
                            'question_type': question_type,
                            'points': jQuery("#points").val(),
                            'testid': $("#testid").val(),
                            'formdata': $("#submit_form").serialize()
                        },
                        success: function(data) {
                            $("#current_questions").html(data);
                            $(".clearfield").val('');
                            $(".clearfieldarea").val('');
                            testid = $("#testid").val();

                        },
                        error: function(errorThrown) {
                            console.log(errorThrown);
                        }
                    });

                }

                function formatResult(item) {
                    var markup = "";
                    if (item.name !== undefined) {
                        markup += "<div>" + item.name + "</div>";
                    }
                    return markup;
                };

                function formatSelection(data) {
                    return data.name;

                };
            </script>
</body>

</html>