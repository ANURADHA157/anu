<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use Session;

class editcontroller extends Controller
{

    // $crud->question_type = $request->q_type;
    // $crud->points = $request->points;

}
