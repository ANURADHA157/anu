<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;


// use Illuminate\Support\Facades\DB;


use App\Models\create;

use Session;

class datacontroller extends Controller
{
    public function product(Request $request)
    {
        $crud = new create();
        $crud->jobtitle = $request->jobtitle;
        $crud->urlkey = $request->urlkey;
        $crud->jobdescription = $request->jobdescription;
        $crud->qualification = $request->qualification;
        $crud->stream1 = $request->stream1;
        $crud->stream2 = $request->stream2;
        $crud->industry = $request->industry;
        $crud->experienceyr = $request->experienceyr;
        $crud->experiencemonth = $request->experiencemonth;
        $crud->salaryfroml = $request->salaryfroml;
        $crud->salaryfromt  = $request->salaryfromt;
        $crud->salarytol  = $request->salarytol;
        $crud->salarytot  = $request->salarytot;
        $crud->joiningtime  = $request->joiningtime;
        $crud->location  = $request->location;
        $crud->no_of_openings = $request->fno_of_openings;
        $crud->status  = $request->status;
        $crud->testid  = $request->testid;
        $crud->testfile  = $request->ftestfile;
        $crud->email_to_send  = $request->email_to_send;
        $crud->company_description = $request->company_description;
        $crud->vdo2  = $request->vdo2;
        $crud->function1 = $request->function1;
        $crud->function2 = $request->function2;

        $crud->save();
        Session::flash('msg', 'Data successfully Added');
        return redirect()->back();
    }


    // public function stream(Request $request)
    // {
    //     $data['function1'] = DB::table('creates')->get();
    //     return view('home', $data);
    // }
}
