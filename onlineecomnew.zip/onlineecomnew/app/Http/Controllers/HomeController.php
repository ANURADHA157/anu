<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;



use App\Models\Crud;
use App\Models\Edit;
use Session;


class HomeController extends Controller
{
    public function index()
    {
        return view('admin.home');
    }




    public function sit()
    {
        return view('admin.myquestionnaire');
    }
    public function dom()
    {
        return view('admin.editquestionnaire');
    }
    public function min()
    {
        return view('admin.addquestionnaire');
    }
    public function mon()
    {


        return view('admin.managetest');
    }



    // public function showData(){
    //     $showData=Crud::all();
    //     return view('show_data',compact('showData'));
    // }

    public function storeData(Request $request)
    {
        // print_r($request->all());
        // die();
        $crud = new Crud();
        // $crud = id();

        $crud->testid = $request->testid;
        $crud->question = $request->question;
        // $crud->answer = $request->answer;
        $crud->question_type = $request->q_type;
        $crud->points = $request->points;
        $crud->save();
        Session::flash('msg', 'Data successfully Added');
        return redirect()->back();
    }


    // if($crud->count()>0){
    // foreach($crud->toArray() as $key=>$value)
    // foreach($value as $row)
    // {
    // $insert_data[]=array(
    //     'question'=>$row['question'],
    //     'answer'=>$row['answer'],
    //     'is_answer'=>$row['is_answer']
    // );
    // }
    // }
    // if(!empty($insert_data)){
    //     DB::table('cruds')->insert($insert_data);

    // }
    // return back()->with('success','excel data imported successfully.');


    // public function Data(Request $request)
    // {
    //     print_r($request->all());
    //     $con = new Crud();
    //     $con->question = $request->question;
    //     $con->id();
    //     $crud->select_tests = $request->Select Questionnaire;
    //     $crud->save();
    //     return redirect()->back();
    // }

    public function insert(Request $request)
    {
        $crud = new Edit();
        $crud->name = $request->name;
        $crud->description = $request->description;
        $crud->save();
        Session::flash('msg', 'Data successfully Added');
        return redirect()->back();
    }
}
