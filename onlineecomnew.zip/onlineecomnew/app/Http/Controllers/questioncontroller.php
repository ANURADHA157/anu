<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Addquestion;
use Session;

class questioncontroller extends Controller
{
    public function check(Request $request)
    {
        $crud = new Addquestion();
        $crud->name = $request->name;
        $crud->description = $request->description;
        $crud->save();
        Session::flash('msg', 'Data successfully Added');
        return redirect()->back();
    }
}
