<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>CareersatCore</title>
<?php echo $__env->make('admin/include/header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<link rel="stylesheet" type="text/css" href="../assets/plugins/select2/select2_metro.css" />

</head>
<body>
<!-- Navbar -->
<?php echo $__env->make('admin/include/navigation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- /navbar -->
 <!-- Page header -->
    <div class="container-fluid">
        <div class="page-header">
            <div class="logo"><a href="index.html" title=""><img src="<?php echo e(asset('assets/img/landinglogo.png')); ?>" style="width:225px;" alt=""></a></div>
            <ul class="middle-nav">
				<li><a href="#" class="btn btn-danger"><i class="fa fa-comments-o"></i> <span>Interviews</span></a><div class="label label-danger">0</div></li>
                <li><a href="#" class="btn btn-success"><i class="fa fa-bars"></i> <span>Analytics</span></a></li>
                <li><a href="#" class="btn btn-info"><i class="fa fa-male"></i> <span>Applicants</span></a></li>
				            </ul>
        </div>
    </div>
    <!-- /page header --><!-- Page container -->
    <div class="page-container container-fluid">
    	<!-- Sidebar -->
        <div class="sidebar collapse">
        	<?php echo $__env->make('admin/include/sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
<!-- Page content -->
<style>
.chats {
  margin:0;
  padding: 0;
  margin-top: -15px;
}

.chats li {
  list-style: none;
  padding: 5px 0;
  margin: 10px auto;
  font-size: 12px;
}
span.body
{
	word-wrap: break-word;
}

.chats li img.avatar {
  height: 45px;
  width: 45px;

}

.chats li.in img.avatar {
  float: left;
  margin-right: 10px;
}

.chats li .name {
  color:#3590c1;
  font-size: 13px;
  font-weight: 400;
}

.show_more,.hide_more
{
	cursor:pointer;
}

.preview td .datetime
{
color:#333;
  font-size: 13px;
  font-weight: 400;
  float:right;
}

.preview td .message .body {
  display: block;
}
.chats li .datetime {
  color:#333;
  font-size: 13px;
  font-weight: 400;
  float:right;
}

.chats li.out img.avatar {
  float: right;
  margin-left: 10px;
}

.chats li .message {
  display: block;
  padding: 5px;
  position: relative;
  font-family: 'Cuprum', sans-serif;
}

.chats li.in .message {
  text-align: left;

  margin-left: 65px;
  background: #fafafa
}

.chats li.in .message .arrow {
  display: block;
  position: absolute;
  top: 5px;
  left: -8px;
  width: 0;
  height: 0;

  border-top: 8px solid transparent;
  border-bottom: 8px solid transparent;
  border-right: 8px solid #35aa47;
}

.chats li.out .message .arrow {
  display: block;
  position: absolute;
  top: 5px;
  right: -8px;
  border-top: 8px solid transparent;
  border-bottom: 8px solid transparent;
  border-left: 8px solid #da4a38;
}

.timestamps {
border-top: 1px solid #e8e8e8;
color: #bfbfbf;
font-size: 11px;
margin: 27px 20px 2px!important;
text-align: center;
color: #bfbfbf;
font-size: 11px;
font-family: 'Cuprum', sans-serif;
text-align: center;border-width: 1px 0 0 0;
}

.timestamps .timestamp {
background-color: #fff;
padding: 0 5px;
position: relative;
top: -15px;
}

.chats li.out .message {
  border-right: 2px solid #da4a38;
  margin-right: 65px;
  background: #fafafa;
  text-align: right;
}

.chats li.out .name,
.chats li.out .datetime  {
  text-align: right;
  font-family: 'Cuprum', sans-serif;
}

.chats li .message .body {
  display: block;
}



</style>
        <div class="page-content">

            <!-- Page title -->
        	<div class="page-title">
                <h5><i class="fa fa-bars"></i>View/Edit your company profile details</h5>
            </div>
           <!-- /page title -->
		     <form method="post" name="contact_form" action="thankyou-jobpost.php" autocomplete="on"  enctype="multipart/form-data" class="custom_form">

				<div id="my-tab-content" class="tab-content">
					<br>
					<div class="tab-pane active" id="step1">

						<div class="form-container col-md-6">
							 <div class="form-group">

							<label for="usernamesignup" class="col-sm-3 control-label">Designation<span style="color:#990000;">*</span></label>

							<div class="col-sm-9">
							<input id="jobtitle" name="jobtitle" required="required" type="text" placeholder="Software Developer" class="field1 form-control form-field-name"/>
							</div>
							</div>
						</div>
						<div class="form-container col-md-6">
							<label for="usernamesignup" class="col-sm-3 control-label">URL Key<span style="color:#990000;">*</span></label>

							<div class="col-sm-9">
							<input id="urlkey" name="urlkey" required="required" type="text" placeholder="Software Developer" class="form-control"/>
							</div>


						</div>
						<div class="clearfix"></div><br>
						<div class="form-container col-md-12">
							<label for="usernamesignup" class="col-sm-3 control-label">Job Description<span style="color:#990000;">*</span></label>
							<div class="clearfix"></div>
							<div class="col-sm-12">
							 <textarea id="elm3" name="jobdescription" rows="10" cols="80" style="width: 100%;border:1px solid #626262!important" class="field1 form-control form-field-name txtareaa"></textarea>
							</div>
						</div>
						<div class="clearfix"></div><br>
						<div class="form-container col-md-12">
								<label for="usernamesignup" class="col-sm-3 control-label" >Educational Stream</label>
								<div class="col-sm-5">

								</div>
								<div class="col-sm-4">
									<select class="select" style="" id="subcategory3" name="function2">
										<option value="">Select sub-stream</option>
									</select>
								</div>
						</div>
						<div class="clearfix"></div><br>
						<div class="form-container col-md-12">
							<label for="emailsignup" class="uname control-label col-md-3">Keywords<span style="color:#990000;">*</span></label>

							<div class="col-md-9">
								<input type="text" id="select2_sample7" value="" name="qualification" class="form-control">
							</div>

						</div>
						<div class="clearfix"></div><br>
						<div class="form-container col-md-12">
							<label for="usernamesignup" class="uname control-label col-md-3" >Functional Stream</label>
							<div class="col-md-9">
								<div class="col-md-6">

								</div>
								<div class="col-md-6">
								<select class="select" style="" id="subcategory1" name="function2" >
									<option value="">Select Subfunctional streams</option>
								</select>
								</div>
							</div>
						</div>
						<div class="clearfix"></div><br>
						<div class="form-container col-md-12">
							<label for="emailsignup" class="uname col-md-3 control-label">Industry<span style="color:#990000;">*</span></label>
							<div class="col-md-9">
								<select id="selectError" data-rel="chosen" name='industry'  class="select" style="width:100%!important">
										<option value="">	INDUSTRY TYPES	</option>
										<option value="Accounting / Finance">	Accounting / Finance	</option>
										<option value="Advertising / PR / MR / Events">	Advertising / PR / MR / Events	</option>
										<option value="Agriculture / Dairy">	Agriculture / Dairy	</option>
										<option value="Animation">	Animation	</option>
										<option value="Architecture / Interior Design">	Architecture / Interior Design	</option>
										<option value="Auto / Auto Ancillary">	Auto / Auto Ancillary	</option>
										<option value="Aviation / Aerospace Firm">	Aviation / Aerospace Firm	</option>
										<option value="Banking / Financial Services / Broking">	Banking / Financial Services / Broking	</option>
										<option value="BPO / ITES">	BPO / ITES	</option>
										<option value="Brewery / Distillery">	Brewery / Distillery	</option>
										<option value="Chemicals / PetroChemical / Plastic / Rubber">	Chemicals / PetroChemical / Plastic / Rubber	</option>
										<option value="Construction / Engineering / Cement / Metals">	Construction / Engineering / Cement / Metals	</option>
										<option value="Consumer Durables">	Consumer Durables	</option>
										<option value="Courier / Transportation / Freight">	Courier / Transportation / Freight	</option>
										<option value="Ceramics /Sanitary ware">	Ceramics /Sanitary ware	</option>
										<option value="Defence / Government">	Defence / Government	</option>
										<option value="Education / Teaching / Training">	Education / Teaching / Training	</option>
										<option value="Electricals / Switchgears">	Electricals / Switchgears	</option>
										<option value="Export / Import	">	Export / Import	</option>
										<option value="Facility Management">	Facility Management	</option>
										<option value="Fertilizers / Pesticides">	Fertilizers / Pesticides	</option>
										<option value="FMCG / Foods / Beverage">	FMCG / Foods / Beverage	</option>
										<option value="Food Processing">	Food Processing	</option>
										<option value="Fresher / Trainee">	Fresher / Trainee	</option>
										<option value="Gems & Jewellery">	Gems & Jewellery	</option>
										<option value="Glass">	Glass	</option>
										<option value="Heat Ventilation Air Conditioning">	Heat Ventilation Air Conditioning	</option>
										<option value="Hotels / Restaurants / Airlines / Travel">	Hotels / Restaurants / Airlines / Travel	</option>
										<option value="Industrial Products / Heavy Machinery">	Industrial Products / Heavy Machinery	</option>
										<option value="Insurance">	Insurance	</option>
										<option value="IT-Software / Software Services	">	IT-Software / Software Services	</option>
										<option value="IT-Hardware & Networking	">	IT-Hardware & Networking	</option>
										<option value="Telecom / ISP">	Telecom / ISP	</option>
										<option value="KPO / Research /Analytics">	KPO / Research /Analytics	</option>
										<option value="Legal">	Legal	</option>
										<option value="Media / Dotcom / Entertainment">	Media / Dotcom / Entertainment	</option>
										<option value="Internet / Ecommerce">	Internet / Ecommerce	</option>
										<option value="Medical / Healthcare / Hospital">	Medical / Healthcare / Hospital	</option>
										<option value="Mining">	Mining	</option>
										<option value="NGO / Social Services">	NGO / Social Services	</option>
										<option value="Office Equipment / Automation">	Office Equipment / Automation	</option>
										<option value="Oil and Gas / Power / Infrastructure / Energy">	Oil and Gas / Power / Infrastructure / Energy	</option>
										<option value="Paper">	Paper	</option>
										<option value="Pharma / Biotech / Clinical Research">	Pharma / Biotech / Clinical Research	</option>
										<option value="Printing / Packaging">	Printing / Packaging	</option>
										<option value="Publishing">	Publishing	</option>
										<option value="Real Estate / Property">	Real Estate / Property	</option>
										<option value="Recruitment">	Recruitment	</option>
										<option value="Retail">	Retail	</option>
										<option value="Security / Law Enforcement">	Security / Law Enforcement	</option>
										<option value="	Semiconductors / Electronics">	Semiconductors / Electronics	</option>
										<option value="Shipping / Marine">	Shipping / Marine	</option>
										<option value="Steel">	Steel	</option>
										<option value="Strategy /Management Consulting Firms">	Strategy /Management Consulting Firms	</option>
										<option value="Textiles / Garments / Accessories">	Textiles / Garments / Accessories	</option>
										<option value="Tyres">	Tyres	</option>
										<option value="Water Treatment / Waste Management	">	Water Treatment / Waste Management	</option>
										<option value="Wellness/Fitness/Sports">	Wellness/Fitness/Sports	</option>
										<option value="Other">	Other	</option>
								</select>
							</div>
						</div>
						<div class="clearfix"></div><br>

						<div class="clearfix"></div><br>
						<br>

						<div class="form-container col-md-12">
							<label for="emailsignup" class="uname col-md-3 control-label">Years of Experience<span style="color:#990000;">*</span></label>
							<div class="col-md-9">

								<div class="col-md-1">to</div>

								<div class="col-md-1">yrs</div>
							</div>
						</div>
						<div class="form-container col-md-12">
							<label for="usernamesignup" class="uname control-label col-md-3" >Salary From</label>
							<div class="col-md-9">
							<select class="select col-md-2" style="width:100%" name="salaryfroml" style="">
								<option value="0">Lac</option>
								<?php for($i=0;$i<51;$i++) {?>
								<option value="<?php echo $i;?>L"> <?php echo $i;?>L </option>
								<?php } ?>
							</select>
							<select class="select col-md-2"  style="width:100%"  name="salaryfromt">
								<option value="">Thousands</option>
								<?php for($i=10000;$i<100000;$i=$i+10000) {?>
								<option value="<?php echo $i;?>"> <?php echo $i;?> </option>
								<?php } ?>
							</select>
							</div>
							<div class="clearfix"></div>
						</div>
						<div class="clearfix"></div><br>
						<div class="form-container col-md-12">
							<label for="usernamesignup" class="uname control-label col-md-3" >Salary To</label>
							<div class="col-md-9">
							<select class="select col-md-2" name="salarytol" style="width:150px" >
								<option value="">Lac</option>
								<?php for($i=1;$i<51;$i++) {?>
								<option value="<?php echo $i;?>L"> <?php echo $i;?>L </option>
								<?php } ?>
							</select>
							<select class="select col-md-2" name="salarytot" style="width:150px">
							</div>
								<option value="">Thousands</option>
								<?php for($i=10000;$i<100000;$i=$i+10000) {?>
								<option value="<?php echo $i;?>"> <?php echo $i;?> </option>
								<?php } ?>
							</select>
							<div class="clearfix"></div>
						</div>
						<div class="clearfix"></div><br>
						<div class="form-container col-md-12">
								<label for="usernamesignup" class="uname control-label col-md-3" style="text-align:left;padding-left:0px;">Joining Time<span style="color:#990000;">*</span></label>

								<div class="col-md-9">
								<input id="form-field-name" name="joiningtime" required="required" type="text" placeholder="1 month" class="form-control field1 form-field-number"/>
								</div>
						</div>
						<div class="clearfix"></div><br>
						<div class="loc_replicate_div">
							<div class="loc_replicate">
							<div class="form-container span5">
								<label for="usernamesignup" class="uname col-md-3 control-label">Location<span style="color:#990000;">*</span></label>
								<div class="col-md-3">
								<input type="text" class="form-control select2_sample5" value="" name="location[]"  style="width:100%" placeholder="Kolkata">
								</div>
								<label for="emailsignup" class="uname col-md-3 control-label">No. of Openings<span style="color:#990000;">*</span></label>
								<div class="col-md-2">
								 <select id="no_of_openings" class='select' name='no_of_openings[]'  >
									<?php
									for($i=1; $i<60; $i++)
									{
										?>
										<option value="<?php echo $i; ?>"><?php echo $i; ?></option>
										<?php
									}
									?>
							   </select>
							   </div>

								<div class="clearfix"></div>
							</div>
							<div class="col-md-1"><a class="add_more_location btn btn-success"> Add More</a>
							   </div>
							<div class="clearfix"></div>
							</div>
						</div>

						<div class="clearfix"></div><br>
						<div class="form-container col-md-6">
							<label for="emailsignup" class="uname col-md-3">Job Type<span style="color:#990000;">*</span></label>

							  <select id="selectError" data-rel="chosen" name='status'  class="select" >
									<option value='Full Time'>Full Time</option>
									<option value='Part Time'>Part Time</option>
									<option value='On Contract'>On Contract</option>
									<option value='Trainee'>Trainee</option>
									<option value='Freelancer'>Freelancer</option>
							   </select>
						</div>

						<div class="form-container col-md-6">
										<label for="emailsignup" class="uname control-label col-md-3">Select Questionnaire<span style="color:#990000;">*</span></label>

										<div class="col-md-9">

											  <div class="clearfix"></div>
											  <span style="float:left;margin:5px 10px;margin-left:0px;">or</span><div class="clearfix"></div>
											  <label for="emailsignup" class="uname span3">Attach Questionnaire<span style="color:#990000;">*</span></label>

												<input type="file" class="default" name="testfile">

										</div>
						</div>
						<div class="clearfix"></div><br>
						<div class="form-container">
							<label for="emailsignup" class="uname col-md-3 control-label">Email Address</label>
							<div class="col-md-9">
								<input type="text" class="form-control" name="email_to_send" value="">
							</div>
						</div>
						<div class="clearfix"></div><br>
						<div class="form-container">
							<label for="emailsignup" class="uname">Company Description</label>
							<div class="span10">
								 <textarea id="elm40" name="company_description"  rows="10" cols="80" style="width: 100%;border:1px solid #626262!important" class="txtareaa"></textarea>
							</div>
						</div><br>
						<div class="clearfix"></div><br>
						<div class="form-container">
							<label for="emailsignup" class="uname  col-md-3 control-label">Upload Job Profile Video</label>
							<div class="col-md-9">
								<input type="file" name="vdo2">
							</div>
						</div>
						<div class="clearfix"></div>
						<div class="form-container">
							<div class="col-md-12">
								<input type="submit"  class="alt_btn read_red btn btn-info pull-right submit_one" name="Submit" style="border:none;" value="Submit"/>
							</div>
						</div>

						<div class="clearfix"></div>
					</div>
					<div class="clearfix"></div>

				</div>
			</form>
		</div>

  <!--<script src="//tinymce.cachefly.net/4.1/tinymce.min.js"></script>-->
  <script src="https://cloud.tinymce.com/stable/tinymce.min.js"></script>

 <script>
  $(function () {

		tinymce.init({
			selector: ".txtareaa",
			theme: "modern",
			plugins: [
				"advlist autolink lists link image charmap print preview hr anchor pagebreak",
				"searchreplace wordcount visualblocks visualchars code fullscreen",
				"insertdatetime media nonbreaking save table contextmenu directionality",
				"emoticons template paste textcolor colorpicker textpattern"
			],
			toolbar1: "insertfile undo redo | styleselect | bold italic | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | link image",
			toolbar2: "print preview media | forecolor backcolor emoticons",
			image_advtab: true,
			setup : function(ed) {
				  ed.on('change', function(e) {
					  if($("#if_changed_val").length > 0)
					  {
						 $("#if_changed_val").val('1');
					  }
				  });
			}
		});

	  });

  $(document).ready(function(){
	  $(".add_more_location").click(function(){

			$(".select2_sample5").select2("destroy");
			$(".loc_replicate_div").append($(".loc_replicate").clone());
			$(".select2_sample5").select2({
				  placeholder: "Enter Locations",
				  tags: true,
				  tokenSeparators: [","],
				  createSearchChoice: function(term, data) {
					if ($(data).filter(function(i) {
						return this.name.localeCompare(term)===0;
					}).length === 0) {
						return {id:term, name:term};
					}
				  },
				  multiple: false,
				  ajax: {
					url: 'getjoblocation.php',
					dataType: "json",
					data: function(term, page) {
					  return {
						q: term
					  };
					},
					results: function(data, page) {
						var data1 = [];
						$.each(data,function(i){
							var item = this;
							data1.push({
								id: item,
								name: item
							});
						});
						return {
							results: data1
					}
					}
				  },
					formatResult: formatResult,
					formatSelection: formatSelection,
					initSelection: function(element, callback) {
						var data = [];
						$(element.val().split(",")).each(function(i) {
							var item = this;
							data.push({
								id: item,
								name: item
							});

						});
						//alert(data);
						//$(element).val('');
						callback(data);
					}
				});
		})
	$("#jobtitle").change(function(){
		jQuery.ajax({
			  url: 'generate-url.php',
			  type:'POST',
			  data:{
				   'action':'generateurl',
				   'string':$(this).val()
			  },
			  success:function(data){
					$("#urlkey").val(data);

			  },
			  error: function(errorThrown){
					console.log(errorThrown);
			  }
		});
	});
	$("#urlkey").change(function(){
		jQuery.ajax({
			  url: 'generate-url.php',
			  type:'POST',
			  data:{
				   'action':'generateurl',
				   'string':$(this).val()
			  },
			  success:function(data){
					$("#urlkey").val(data);

			  },
			  error: function(errorThrown){
					console.log(errorThrown);
			  }
		});
	});

		$("#parentcat2").change(function(){
				var parentid = $(this).find("option:selected").val();
				getchildcat1(parentid,'subcategory3');
			 });
			  function getchildcat1(parentid,subcatid){

				jQuery.ajax({
						  url: 'getinternchildcat.php',
							 type:'POST',
						  data:{
							   'action':'getchildcat',
							   'parentid':parentid
						  },
						  success:function(data){
//								   alert(data);
								if(data.length > 2 )
								   {
										$("#"+subcatid).append(data);
										$("#"+subcatid).chosen();
										$("#subdiv").show();
								   }

						  },
						  error: function(errorThrown){
								console.log(errorThrown);
						  }
				});
			}
		 $("#parentcat").change(function(){
				var parentid = $(this).find("option:selected").val();
				getchildcat(parentid,'subcategory1');
			 });
			  function getchildcat(parentid,subcatid){

				jQuery.ajax({
						  url: 'getchildcat.php',
							 type:'POST',
						  data:{
							   'action':'getchildcat',
							   'parentid':parentid
						  },
						  success:function(data){
//								   alert(data);
								if(data.length > 2 )
								   {
										$("#"+subcatid).append(data);
										$("#"+subcatid).chosen();
										$("#subdiv").show();
								   }

						  },
						  error: function(errorThrown){
								console.log(errorThrown);
						  }
				});
			}
		$(".select").select2();
		 tinyMCE.init({
			// General options
			mode : "exact",
			elements : "elm3",
			theme : "advanced",
			skin : "o2k7",
			skin_variant : "silver",
			plugins : "lists,pagebreak,style,layer,table,save,advhr,advimage,advlink,emotions,iespell,insertdatetime,preview,media,searchreplace,print,contextmenu,paste,directionality,fullscreen,noneditable,visualchars,nonbreaking,xhtmlxtras,template,inlinepopups,autosave",
			// Theme options
			theme_advanced_buttons1 : "save,newdocument,|,bold,italic,underline,strikethrough,|,justifyleft,justifycenter,justifyright,justifyfull,styleselect,formatselect,fontselect,fontsizeselect",
			theme_advanced_buttons2 : "cut,copy,paste,pastetext,pasteword,|,search,replace,|,bullist,numlist,|,outdent,indent,blockquote,|,undo,redo,|,link,unlink,anchor,image,cleanup,help,code,|,insertdate,inserttime,preview,|,forecolor,backcolor",
			theme_advanced_buttons3 : "tablecontrols,|,hr,removeformat,visualaid,|,sub,sup,|,charmap,emotions,iespell,media,advhr,|,print,|,ltr,rtl,|,fullscreen",
			theme_advanced_buttons4 : "insertlayer,moveforward,movebackward,absolute,|,styleprops,|,cite,abbr,acronym,del,ins,attribs,|,visualchars,nonbreaking,template,pagebreak,restoredraft",
			theme_advanced_toolbar_location : "top",
			theme_advanced_toolbar_align : "left",
			theme_advanced_statusbar_location : "bottom",
			theme_advanced_resizing : true,
			// Drop lists for link/image/media/template dialogs
			template_external_list_url : "lists/template_list.js",
			external_link_list_url : "lists/link_list.js",
			external_image_list_url : "lists/image_list.js",
			media_external_list_url : "lists/media_list.js",
		  });

		$("#select2_sample7").select2({
		  placeholder: "Enter Skills",
		  tags: true,
		  tokenSeparators: [","],
		  createSearchChoice: function(term, data) {
			if ($(data).filter(function(i) {
				return this.name.localeCompare(term)===0;
			}).length === 0) {
				return {id:term, name:term};
			}
		  },
		  multiple: true,
		  ajax: {
			url: 'getskills.php',
			dataType: "json",
			data: function(term, page) {
			  return {
				q: term
			  };
			},
			results: function(data, page) {
				var data1 = [];
				$.each(data,function(i){
					var item = this;
                    data1.push({
						id: item,
                        name: item
                    });
				});
				return {
					results: data1
			}
			}
		  },
            formatResult: formatResult,
            formatSelection: formatSelection,
            initSelection: function(element, callback) {
                var data = [];
				$(element.val().split(",")).each(function(i) {
                    var item = this;
                    data.push({
						id: item,
                        name: item
                    });

                });
				//alert(data);
				//$(element).val('');
                callback(data);
            }
		});

		$(".select2_sample5").select2({
		  placeholder: "Enter Locations",
		  tags: true,
		  tokenSeparators: [","],
		  createSearchChoice: function(term, data) {
			if ($(data).filter(function(i) {
				return this.name.localeCompare(term)===0;
			}).length === 0) {
				return {id:term, name:term};
			}
		  },
		  multiple: false,
		  ajax: {
			url: 'getjoblocation.php',
			dataType: "json",
			data: function(term, page) {
			  return {
				q: term
			  };
			},
			results: function(data, page) {
				var data1 = [];
				$.each(data,function(i){
					var item = this;
                    data1.push({
						id: item,
                        name: item
                    });
				});
				return {
					results: data1
			}
			}
		  },
            formatResult: formatResult,
            formatSelection: formatSelection,
            initSelection: function(element, callback) {
                var data = [];
				$(element.val().split(",")).each(function(i) {
                    var item = this;
                    data.push({
						id: item,
                        name: item
                    });

                });
				//alert(data);
				//$(element).val('');
                callback(data);
            }
		});

  });
  function formatResult(item) {
			var markup = "";
			if (item.name !== undefined) {
				markup += "<div>" + item.name + "</div>";
			}
			return markup;
		};

		function formatSelection(data) {
			return data.name;

		};

  </script>
  <!-- javascript at the bottom for fast page loading -->
            <!--<div class="footer">
                &copy; Copyright 2011. All rights reserved. It's Brain admin theme by <a href="#" title="">Eugene Kopyov</a>
            </div>-->
            <!-- /footer -->

        </div>
    </div>
</body>
</html>	</body>
</html>
<?php /**PATH D:\xampp\htdocs\onlineecomnew\resources\views/admin/home.blade.php ENDPATH**/ ?>