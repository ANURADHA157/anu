<link href="<?php echo e(asset('assets/css/bootstrap.min.css')); ?>" rel="stylesheet" type="text/css">
<link href="<?php echo e(asset('assets/css/brain-theme.css')); ?>" rel="stylesheet" type="text/css">
<link href="<?php echo e(asset('assets/css/styles.css')); ?>" rel="stylesheet" type="text/css">
<link href="<?php echo e(asset('assets/css/font-awesome.min.css')); ?>" rel="stylesheet" type="text/css">
<link href="<?php echo e(asset('assets/css/mystyle.css')); ?>" rel="stylesheet" type="text/css">
<link href='https://fonts.googleapis.com/css?family=Cuprum' rel='stylesheet' type='text/css'>

<script type="text/javascript" src="<?php echo e(asset('assets/js/jquery.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('assets/js/jquery-ui.min.js')); ?>"></script>

<script type="text/javascript" src="<?php echo e(asset('assets/js/custom.js')); ?>"></script>


<!--<script type="text/javascript" src="<?php echo e(asset('assets/js/plugins/charts/flot.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('assets/js/plugins/charts/flot.orderbars.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('assets/js/plugins/charts/flot.pie.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('assets/js/plugins/charts/flot.time.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('assets/js/plugins/charts/flot.animator.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('assets/js/plugins/charts/excanvas.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('assets/js/plugins/charts/flot.resize.min.js')); ?>"></script>
-->
<script type="text/javascript" src="<?php echo e(asset('assets/js/plugins/forms/uniform.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('assets/js/plugins/forms/select2.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('assets/js/plugins/forms/inputmask.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('assets/js/plugins/forms/autosize.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('assets/js/plugins/forms/inputlimit.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('assets/js/plugins/forms/listbox.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('assets/js/plugins/forms/multiselect.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('assets/js/plugins/forms/validate.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('assets/js/plugins/forms/tags.min.js')); ?>"></script>

<script type="text/javascript" src="<?php echo e(asset('assets/js/plugins/forms/uploader/plupload.full.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('assets/js/plugins/forms/uploader/plupload.queue.min.js')); ?>"></script>

<script type="text/javascript" src="<?php echo e(asset('assets/js/plugins/forms/wysihtml5/wysihtml5.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('assets/js/plugins/forms/wysihtml5/toolbar.js')); ?>"></script>

<script type="text/javascript" src="<?php echo e(asset('assets/js/plugins/interface/jgrowl.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('assets/js/plugins/interface/datatables.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('assets/js/plugins/interface/prettify.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('assets/js/plugins/interface/fancybox.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('assets/js/plugins/interface/colorpicker.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('assets/js/plugins/interface/timepicker.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('assets/js/plugins/interface/fullcalendar.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('assets/js/plugins/interface/collapsible.min.js')); ?>"></script>

<script type="text/javascript" src="<?php echo e(asset('assets/js/bootstrap.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('assets/js/application.js')); ?>"></script>
<?php /**PATH C:\xampp\htdocs\onlineecomnew\resources\views/admin/include/header.blade.php ENDPATH**/ ?>