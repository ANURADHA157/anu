  <html lang="en">

  <head>
      <meta charset="utf-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <title>CareersatCore</title>


      <?php echo $__env->make('admin/include/header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


      <!-- <link rel="stylesheet" type="text/css" href="../assets/plugins/select2/select2_metro.css" /> -->
      <!-- <link rel="stylesheet" type="text/css" href="//cdn.datatables.net/1.10.11/css/jquery.dataTables.min.css"> -->
      <!--<script type="text/javascript" src="<assets/js/charts/simple_graph.js"></script>-->
  </head>

  <body>
      <!-- Navbar -->

      <?php echo $__env->make('admin/include/navigation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>






      <!-- /navbar -->
      <!-- Page header -->
      <div class="container-fluid">
          <div class="page-header">
              <div class="logo"><a href="index.html" title=""><img src="<?php echo e(asset('assets/img/landinglogo.png')); ?>" style="width:225px;" alt=""></a></div>
              <ul class="middle-nav">
                  <li><a href="#" class="btn btn-danger"><i class="fa fa-comments-o"></i> <span>Interviews</span></a>
                      <div class="label label-danger">0</div>
                  </li>
                  <li><a href="#" class="btn btn-success"><i class="fa fa-bars"></i> <span>Analytics</span></a></li>
                  <li><a href="#" class="btn btn-info"><i class="fa fa-male"></i> <span>Applicants</span></a></li>
              </ul>
          </div>
      </div>
      <!-- /page header -->
      <!-- Page container -->
      <div class="page-container container-fluid">
          <!-- Sidebar -->
          <div class="sidebar collapse">



              <?php echo $__env->make('admin/include/sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



          </div>

          <div class="page-content">
              <div class="page-title">
                  <h5><i class="fa fa-bars"></i>Manage Quesionnaire</h5>
              </div>
              <!-- /page title -->
              <!-- /page title -->
              <div class="panel panel-default">
                  <div class="panel-heading">
                      <h6 class="panel-title">All Questionnaires - 9 entries</h6>
                      <a href="<?php echo e(url('/')); ?>/addquestionnaire" style="float:right"><button class="btn btn-xs btn-success" type="button" id="my-button" style="margin-right:10px">Add New</button></a>
                  </div>
                  <div class="panel-body" style="padding-top:0px;padding-bottom:0px">
                      <div class="row" style="padding:5px 10px;">
                          <div class="wrapper">

                              <div class="clearfix"></div>
                              <div>
                                  <table id="datatable_example" class="responsive table table-striped table-bordered" style="width:100%;margin-bottom:0; " style="border-collapse:collapse">
                              </div>
                              <thead>
                                  <tr>
                                      <th>Name</th>
                                      <th>Description</th>
                                      <th>Created Date</th>
                                      <th>Actions</th>
                                  </tr>
                              </thead>
                              <tbody>




                                  <tr>
                                      <td>Test Ques </td>
                                      <td>Desc Test Ques</td>
                                      <td>2020-11-25</td><br>






                                      <td>

                                          <a class="" rel="tooltip" data-placement="left" data-original-title="Edit" href="<?php echo e(url('/')); ?>/editquestionnaire?to=" title="Edit">
                                              <i class="fa fa-pencil"></i>
                                          </a>|

                                          <a class="" rel="tooltip" data-placement="left" data-original-title="Questions" href="<?php echo e(url('/')); ?>/managetest?to=" title="Questions">
                                              <i class="fa fa-question-circle"></i>

                                          </a> |
                                          <a class="" rel="tooltip" data-placement="left" data-original-title="Delete" href="javascript:confirmChoice('')" title="Delete">
                                              <i class="fa fa-times"></i>
                                          </a> |















                                          <!-- <i class="fa fa-times"></i> -->

                                          <!-- </a> | -->
                                          <div class="clearfix"></div>
                                      </td>
                                  </tr>

                                  <tr>
                                      <td>CTO / Team Lead Backend Developer / Full Stack – Bangalore – Funded ELearning Startup </td>
                                      <td>Tech stack: Java and Springboot; DBs - Mongo, SQL and Postgres</td>
                                      <td>2020-11-07</td><br>


                                      <td>

                                          <a class="" rel="tooltip" data-placement="left" data-original-title="Edit" href="<?php echo e(url('/')); ?>/editquestionnaire?to=" title="Edit">
                                              <i class="fa fa-pencil"></i>
                                          </a>|

                                          <a class="" rel="tooltip" data-placement="left" data-original-title="Questions" href="<?php echo e(url('/')); ?>/managetest?to=" title="Questions">
                                              <i class="fa fa-question-circle"></i>

                                          </a> |
                                          <a class="" rel="tooltip" data-placement="left" data-original-title="Delete" href="javascript:confirmChoice('')" title="Delete">
                                              <i class="fa fa-times"></i>
                                          </a> |

                                          <div class="clearfix"></div>
                                      </td>
                                  </tr>

                                  <tr>
                                      <td>Agency Manager Kolkata - Very Large Group </td>
                                      <td>Agency Manager Kolkata - Very Large Group</td>
                                      <td>2020-10-15</td><br>


                                      <td>

                                          <a class="" rel="tooltip" data-placement="left" data-original-title="Edit" href="<?php echo e(url('/')); ?>/editquestionnaire?to=" title="Edit">
                                              <i class="fa fa-pencil"></i>
                                          </a>|

                                          <a class="" rel="tooltip" data-placement="left" data-original-title="Questions" href="<?php echo e(url('/')); ?>/managetest?to=" title="Questions">
                                              <i class="fa fa-question-circle"></i>

                                          </a> |
                                          <a class="" rel="tooltip" data-placement="left" data-original-title="Delete" href="javascript:confirmChoice('')" title="Delete">
                                              <i class="fa fa-times"></i>
                                          </a> |

                                          <div class="clearfix"></div>
                                      </td>
                                  </tr>

                                  <tr>
                                      <td>BPOE </td>
                                      <td>QuestionsNoida</td>
                                      <td>2016-05-25</td><br>


                                      <td>

                                          <a class="" rel="tooltip" data-placement="left" data-original-title="Edit" href="<?php echo e(url('/')); ?>/editquestionnaire?to=" title="Edit">
                                              <i class="fa fa-pencil"></i>
                                          </a>|

                                          <a class="" rel="tooltip" data-placement="left" data-original-title="Questions" href="<?php echo e(url('/')); ?>/managetest?to=" title="Questions">
                                              <i class="fa fa-question-circle"></i>

                                          </a> |
                                          <a class="" rel="tooltip" data-placement="left" data-original-title="Delete" href="javascript:confirmChoice('')" title="Delete">
                                              <i class="fa fa-times"></i>
                                          </a> |

                                          <div class="clearfix"></div>
                                      </td>
                                  </tr>

                                  <tr>
                                      <td>PHP Consultant </td>
                                      <td>PHP Consultant</td>
                                      <td>2016-04-14</td><br>


                                      <td>

                                          <a class="" rel="tooltip" data-placement="left" data-original-title="Edit" href="<?php echo e(url('/')); ?>/editquestionnaire?to=" title="Edit">
                                              <i class="fa fa-pencil"></i>
                                          </a>|

                                          <a class="" rel="tooltip" data-placement="left" data-original-title="Questions" href="<?php echo e(url('/')); ?>/managetest?to=" title="Questions">
                                              <i class="fa fa-question-circle"></i>

                                          </a> |
                                          <a class="" rel="tooltip" data-placement="left" data-original-title="Delete" href="javascript:confirmChoice('')" title="Delete">
                                              <i class="fa fa-times"></i>
                                          </a> |

                                          <div class="clearfix"></div>
                                      </td>
                                  </tr>



                                  <tr>
                                      <td>TestingLex </td>
                                      <td>TestingLex</td>
                                      <td>2016-04-13</td><br>


                                      <td>

                                          <a class="" rel="tooltip" data-placement="left" data-original-title="Edit" href="<?php echo e(url('/')); ?>/editquestionnaire?to=" title="Edit">
                                              <i class="fa fa-pencil"></i>
                                          </a>|

                                          <a class="" rel="tooltip" data-placement="left" data-original-title="Questions" href="<?php echo e(url('/')); ?>/managetest?to=" title="Questions">
                                              <i class="fa fa-question-circle"></i>

                                          </a> |
                                          <a class="" rel="tooltip" data-placement="left" data-original-title="Delete" href="javascript:confirmChoice('')" title="Delete">
                                              <i class="fa fa-times"></i>
                                          </a> |

                                          <div class="clearfix"></div>
                                      </td>
                                  </tr>



                                  <tr>
                                      <td>Asp.net </td>
                                      <td>Asp.netJ</td>
                                      <td>2016-04-09</td><br>


                                      <td>

                                          <a class="" rel="tooltip" data-placement="left" data-original-title="Edit" href="<?php echo e(url('/')); ?>/editquestionnaire?to=" title="Edit">
                                              <i class="fa fa-pencil"></i>
                                          </a>|

                                          <a class="" rel="tooltip" data-placement="left" data-original-title="Questions" href="<?php echo e(url('/')); ?>/managetest?to=" title="Questions">
                                              <i class="fa fa-question-circle"></i>

                                          </a> |
                                          <a class="" rel="tooltip" data-placement="left" data-original-title="Delete" href="javascript:confirmChoice('')" title="Delete">
                                              <i class="fa fa-times"></i>
                                          </a> |

                                          <div class="clearfix"></div>
                                      </td>
                                  </tr>


                                  <tr>
                                      <td>ContentWriter </td>
                                      <td>ContentWriter</td>
                                      <td>2016-04-05</td><br>


                                      <td>

                                          <a class="" rel="tooltip" data-placement="left" data-original-title="Edit" href="<?php echo e(url('/')); ?>/editquestionnaire?to=" title="Edit">
                                              <i class="fa fa-pencil"></i>
                                          </a>|

                                          <a class="" rel="tooltip" data-placement="left" data-original-title="Questions" href="<?php echo e(url('/')); ?>/managetest?to=" title="Questions">
                                              <i class="fa fa-question-circle"></i>

                                          </a> |
                                          <a class="" rel="tooltip" data-placement="left" data-original-title="Delete" href="javascript:confirmChoice('')" title="Delete">
                                              <i class="fa fa-times"></i>
                                          </a> |

                                          <div class="clearfix"></div>
                                      </td>
                                  </tr>

                                  <tr>
                                      <td>AccountsIn </td>
                                      <td>AccountsIn</td>
                                      <td>2016-04-02</td><br>


                                      <td>

                                          <a class="" rel="tooltip" data-placement="left" data-original-title="Edit" href="<?php echo e(url('/')); ?>/editquestionnaire?to=" title="Edit">
                                              <i class="fa fa-pencil"></i>
                                          </a>|

                                          <a class="" rel="tooltip" data-placement="left" data-original-title="Questions" href="<?php echo e(url('/')); ?>/managetest?to=" title="Questions">
                                              <i class="fa fa-question-circle"></i>

                                          </a> |
                                          <a class="" rel="tooltip" data-placement="left" data-original-title="Delete" href="javascript:confirmChoice('')" title="Delete">
                                              <i class="fa fa-times"></i>
                                          </a> |

                                          <div class="clearfix"></div>
                                      </td>
                                  </tr>








                              </tbody>
                              </table>
                              <div style="clear:both"></div>
                          </div>

                      </div>

                  </div>

              </div>


              <script type="text/javascript" language="javascript" src="js/jquery-1.8.2.min.js"></script>
              <script src="js/jquery.stepy.min.js"></script>
              <script type="text/javascript" src="assets/plugins/bootstrap-fileupload/bootstrap-fileupload.js"></script>
              <script type="text/javascript" src="assets/plugins/select2/select2.min.js"></script>
              <script type="text/javascript" src="assets/plugins/jquery-tags-input/jquery.tagsinput.min.js"></script>
              <script type="text/javascript" src="assets/plugins/tinymce/jscripts/tiny_mce/tiny_mce.js"></script>
              <script>
                  function confirmChoice(j) {
                      msgQuestion = "Confirm Delete!";
                      userResponse = confirm(msgQuestion);
                      if (userResponse == 1) {
                          location = "<?php echo e(url('/')); ?>/myquestionnaire ? del = del & co = " + j;
                      } else {
                          return;
                      }
                  }
              </script>
              <!-- javascript at the bottom for fast page loading -->


  </body>

  </html><?php /**PATH C:\xampp\htdocs\onlineecomnew\resources\views/admin/myquestionnaire.blade.php ENDPATH**/ ?>