<?php
include "/home/careersatcore/public_html/assets/include/email.php";
require_once("query.php");
$obj=new raw;
$h = "localhost"; /*hostname*/
$u = "careersa_corenew";
$p = "7M)cT_U_fH?PFj]Dj)";
$d = "careersa_corenew";
$t = "admin"; /*tablename*/

/*
$ho = "corebeta.db.11847350.hostedresource.com";
$us = "corebeta";
$pa = "Careers123#";
$da = "corebeta";
$ta = "tbladmin";
*/

$obj->connect_db($h,$u,$p,$d,$t);

//$obj->connect_db($ho,$us,$pa,$da,$ta);
$obj->acetables();

$obj->admin_emailid("rajiv@careersatcore.com");
?>