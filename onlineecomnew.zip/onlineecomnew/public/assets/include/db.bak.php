<?php
require_once("query.php");
$obj=new raw;
$h = "localhost"; /*hostname*/
$u = "saketpro_corenew";
$p = "351gbPBM$";
$d = "saketpro_corenew";
$t = "admin"; /*tablename*/
$ho = "corebeta.db.11847350.hostedresource.com";
$us = "corebeta";
$pa = "Careers123#";
$da = "corebeta";
$ta = "tbladmin";

$obj->connect_db($h,$u,$p,$d,$t);

//$obj->connect_db($ho,$us,$pa,$da,$ta);
$obj->acetables();

$obj->admin_emailid("sneh.khaitan@gmail.com");
?>