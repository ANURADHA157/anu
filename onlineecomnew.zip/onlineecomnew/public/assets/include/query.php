<?php
//require_once("query_stru.php");
//require_once("class.phpmailer.php");
error_reporting(E_ALL ^ E_NOTICE);
class raw
{
	var $rand_key;
	var $from_address;
    var $error_message;
	
	
//-----Initialization -------

	function __construct()
	{
	 $this->sitename = 'rawaangi.com';
	 $this->rand_key = '0iQx5oBk66oVZep';
	}

	
	function connect_db($host,$uname,$pwd,$database,$tablename)
	{
	$this->db_host  = $host;
    $this->username = $uname;
    $this->pwd  = $pwd;
    $this->database  = $database;
	$this->tablename = $tablename;
	$connect=mysql_connect($this->db_host,$this->username,$this->pwd) or die("can not connect to server!");
	mysql_select_db($this->database,$connect)  or die("can not connect to database!");
	
	}
	
	function admin_emailid($admin_e_id)
	{
		$this->receiver = $admin_e_id;
	}
    
	function CreatePassword($length)
	{

	}


    function GetSelfScript()
    {
        return htmlentities($_SERVER['PHP_SELF']);
    } 
	
	function GetErrorMessage()
    {
        if(empty($this->error_message))
        {
            return '';
        }
        $errormsg = nl2br(htmlentities($this->error_message));
        return $errormsg;
    }       

/*
    Sanitize() function removes any potential threat from the
    data submitted. Prevents email injections or any other hacker attempts.
    if $remove_nl is true, newline chracters are removed from the input.
    */
	
	function SanitizeForSQL($str)
    {
        if( function_exists( "mysql_real_escape_string" ) )
        {
              $ret_str = mysql_real_escape_string( $str );
        }
        else
        {
              $ret_str = addslashes( $str );
        }
        return $ret_str;
    }
	
	
    function Sanitize($str,$remove_nl=true)
    {
        $str = $this->StripSlashes($str);

        if($remove_nl)
        {
            $injections = array('/(\n+)/i',
                '/(\r+)/i',
                '/(\t+)/i',
                '/(%0A+)/i',
                '/(%0D+)/i',
                '/(%08+)/i',
                '/(%09+)/i'
                );
            $str = preg_replace($injections,'',$str);
        }

        return $str;
    }    
	
	function RedirectToURL($url)
    {
        header("Location: $url");
        exit;
    }
	
	function StripSlashes($str)
    {
        if(get_magic_quotes_gpc())
        {
            $str = stripslashes($str);
        }
        return $str;
    }    
	
    function HandleError($err)
    {
        $this->error_message .= $err."\r\n";
    }
    
    function HandleDBError($err)
    {
        $this->HandleError($err."\r\n mysqlerror:".mysql_error());
    }
	
	
	function GetFromAddress()
    {
        if(!empty($this->from_address))
        {
            return $this->from_address;
        }

        $host = $_SERVER['SERVER_NAME'];

        $from ="nobody@$host";
        return $from;
    } 
	
	function GetAbsoluteURLFolder()
    {
        $scriptFolder = (isset($_SERVER['HTTPS']) && ($_SERVER['HTTPS'] == 'on')) ? 'https://' : 'https://';
        $scriptFolder .= $_SERVER['HTTP_HOST'] . dirname($_SERVER['REQUEST_URI']);
        return $scriptFolder;
    }

	function GetContent($name,$lang)
		{
			if(!$this->DBLogin())
			{
				$this->HandleError("Database login failed!");
				return false;
			}

			$qry = "select * from tblcontent where title='".$name."'";
			
			$result = mysql_query($qry,$this->connection);  

			if(!$result && mysql_num_rows($result) > 0)
			{
				return false;
			}
			$row = mysql_fetch_assoc($result);
			
			$content = $row['content'];
			
			return $content;

		}



	function AddCategory()
	{
		$catname = trim(mysql_escape_string($_POST['catname']));
		$meta_title = trim(mysql_escape_string($_POST['meta_title']));
		$meta_description = trim(mysql_escape_string($_POST['meta_description']));
		$status = trim(mysql_escape_string($_POST['status']));
		if(!empty($_POST['sub1']) && !($_POST['sub1'] == '-1') )
			$parentid = trim($_POST['sub1']);
		else
	        $parentid = trim($_POST['parentid']);	
			$query1 = mysql_query("select * from tblcategory where catname = '$catname' and parentid = '$parentid'") or die("all:".mysql_error());
		if(mysql_num_rows($query1)<=0)
		{
			$date = date('Y-m-d');
			echo "insert into tblcategory (catname,status,parentid,meta_title,meta_description, createddate) values ('$catname','$status','$parentid','$meta_title','$meta_description', '$date')";
			$update = mysql_query("insert into tblcategory (catname,status,parentid,meta_title,meta_description, createddate) values ('$catname','$status','$parentid','$meta_title','$meta_description', '$date')");
			$refid =  mysql_insert_id();
			return true;
		}
		else
		{
			return false;
		}
	}

function draw_calendar($month,$year,$events = array()){

	/* draw table */
	$calendar = '<table cellpadding="0" cellspacing="0" class="calendar">';

	/* table headings */
	$headings = array('SUN','MON','TUE','WED','THU','FRI','SAT');
	$calendar.= '<tr class="calendar-row"><td class="calendar-day-head">'.implode('</td><td class="calendar-day-head">',$headings).'</td></tr>';

	/* days and weeks vars now ... */
	$running_day = date('w',mktime(0,0,0,$month,1,$year));
	$days_in_month = date('t',mktime(0,0,0,$month,1,$year));
	$days_in_this_week = 1;
	$day_counter = 0;
	$dates_array = array();

	/* row for week one */
	$calendar.= '<tr class="calendar-row">';

	/* print "blank" days until the first of the current week */
	for($x = 0; $x < $running_day; $x++):
		$calendar.= '<td class="calendar-day-np">&nbsp;</td>';
		$days_in_this_week++;
	endfor;

	/* keep going with days.... */
	for($list_day = 1; $list_day <= $days_in_month; $list_day++):
		$calendar.= '<td class="calendar-day"><div style="position:relative;height:80px;">';
			/* add in the day number */
			$calendar.= '<div class="day-number">'.$list_day.'</div>';
			
			$event_day = $year.'-'.$month.'-'.$list_day;
		//	print_r($events);

			if(isset($events[$event_day])) {
				foreach($events[$event_day] as $event) {
					
				    $d = date("g:i a", strtotime($event['event_time']));
					$name = $event['fullname'];
					$calendar.= '<div class="event"><a href="javascript:void(0);" id="d<?php echo $list_day; ?>" class="listday" title="'.$name.'">'.$d.'</a></div>';
				}
			}
			else {
				$calendar.= str_repeat('<p>&nbsp;</p>',2);
			}
		$calendar.= '</div></td>';
		if($running_day == 6):
			$calendar.= '</tr>';
			if(($day_counter+1) != $days_in_month):
				$calendar.= '<tr class="calendar-row">';
			endif;
			$running_day = -1;
			$days_in_this_week = 0;
		endif;
		$days_in_this_week++; $running_day++; $day_counter++;
	endfor;

	/* finish the rest of the days in the week */
	if($days_in_this_week < 8):
		for($x = 1; $x <= (8 - $days_in_this_week); $x++):
			$calendar.= '<td class="calendar-day-np">&nbsp;</td>';
		endfor;
	endif;

	/* final row */
	$calendar.= '</tr>';
	

	/* end the table */
	$calendar.= '</table>';

	/** DEBUG **/
	$calendar = str_replace('</td>','</td>'."\n",$calendar);
	$calendar = str_replace('</tr>','</tr>'."\n",$calendar);
	
	/* all done, return result */
	return $calendar;
}
	
	
	//-------------user login function------------
	
/*************Admin Login panel*************/

	function acetables()
	{
		$this->tablenameadmin = "tbladmin";
		$this->tablenamementor = "tblemployers";
		$this->tablenamestudents = "tblemployees";
	}

	function CheckLoginInEmployer()
	{
		if(!isset($_POST['submittedlogin']))
		{
			return false;
		}
		$loginvarad = array();
		$this->collectinfoForAdmin($loginvarad);
        return $this->checkMentor($loginvarad);		
	}
	function CheckLoginInEmployee()
	{
		if(!isset($_POST['submittedlogin']))
		{
			return false;
		}
		
 		$loginvarad = array();
		
		$this->collectinfoForAdmin($loginvarad);
        return $this->checkStudent($loginvarad);		
		
    }

	function CheckLoginInAdmin()
	{
		if(!isset($_POST['submitted']))
		{
			return false;
		}
		
 		$loginvarad = array();
		
		$this->collectinfoForAdmin($loginvarad);
        return $this->checkAdmin($loginvarad);		
		
    }
	
	
	function checkMentor(&$loginvarad)
	{
		$adminname = $loginvarad['username_field'];
		$adminpwd = $loginvarad['password_field'];
		$qryadm = "Select * from $this->tablenamementor as a where a.email='$adminname' and a.password='$adminpwd'"; 
		$resadmin = mysql_query($qryadm);
		if(mysql_num_rows($resadmin)<=0)
		{
			$this->HandleError("The username or password does not match");
			echo '0';die();
			return false;
		}
		
		$row = mysql_fetch_assoc($resadmin);
		$_SESSION['username']  = $loginvarad['username_field'];
		$_SESSION['userid']    = $row['id'];
		$_SESSION['usertype']    = 'employer';
		echo '1';die();
		
		return true;		
	}	
	function logoutMentor()
	{
		$qryadm = mysql_query("update $this->tablenamementor set if_online='0' where id='".$_SESSION['userid']."'");       
	}
	function logoutStudent()
	{
		$qryadm = mysql_query("update $this->tablenamestudents set if_online='0' where id='".$_SESSION['userid']."'");       
	}
	function checkStudent(&$loginvarad)
	{
		$adminname = $loginvarad['username_field'];
		$adminpwd = $loginvarad['password_field'];
		$qryadm = "Select * from $this->tablenamestudents as a where a.email='$adminname' and a.password='$adminpwd'";      
		
		if(!mysql_query($qryadm))
		{
			$this->HandleError("The username or password does not match");
			return false;
		}
		$resadmin = mysql_query($qryadm);
		$rowsadm = mysql_num_rows($resadmin);
		
		if(!$rowsadm)
		{
			$this->HandleError("The username or password does not match");
			return false;
		}
		$row = mysql_fetch_assoc($resadmin);
		
		session_start();
		$_SESSION['username']  = $loginvarad['username_field'];
		$_SESSION['userid']    = $row['id'];
		$_SESSION['usertype']    = 'employee';
		echo '1';die();
			
	}	

	function GetMyUnreadMessages($id,$type)
	{
		$qryadm = "Select *,DATE(message_date) AS message_date, TIME(message_date) AS message_time from tblmessages as a where (a.tomember='$id' and a.totype='$type') and if_unread='1' group by a.frommember";      

	
		$resadmin = mysql_query($qryadm);
		if(!$resadmin)
		{
			$this->HandleError("No Messages");
			return false;
		}
		return mysql_num_rows($resadmin);
	}

	function GetMyMessages($id,$type)
	{
		$qryadm = "Select *,DATE(message_date) AS message_date, TIME(message_date) AS message_time from tblmessages as a where ((a.frommember='$id' and a.fromtype='$type') or (a.tomember='$id' and a.totype='$type')) and replyid=0 order by message_date desc";      
	
		$resadmin = mysql_query($qryadm);
		if(!$resadmin)
		{
			$this->HandleError("No Messages");
			return false;
		}
		return $resadmin;
	}
	function UpdateUnread($chatid,$usertype)
	{
		$qryreply= mysql_query("Select *,DATE(message_date) AS message_date, TIME(message_date) AS message_time from tblmessages as a where id='$chatid'") or die("all:".mysql_error());
		$arr = array();$s = 0;
		if(mysql_num_rows($qryreply)>0)
		{
			do{
				$s++;
				$resultreply = mysql_fetch_array($qryreply);
				$chasid = $resultreply['id'];
				$qs = mysql_query("Update tblmessages set if_unread='0' where id='".$chasid."' and totype='".$usertype."' and if_unread='1'");				
				$arr[$s] = $resultreply;
				$qryreply= mysql_query("select *,DATE(message_date) AS message_date, TIME(message_date) AS message_time from tblmessages where replyid='".$resultreply['id']."'") or die("all:".mysql_error());
			}while(mysql_num_rows($qryreply)>0);
		}

	}

	function RetrieveFullChat($chatid)
	{
	//	$qryadm = "Select *,DATE(message_date) AS message_date, TIME(message_date) AS message_time from tblmessages as a where id='$chatid'";      
		$qryreply= mysql_query("Select *,DATE(message_date) AS message_date, TIME(message_date) AS message_time from tblmessages as a where id='$chatid'") or die("all:".mysql_error());
		$arr = array();$s = 0;
		if(mysql_num_rows($qryreply)>0)
		{
			do{
				$s++;
				$resultreply = mysql_fetch_array($qryreply);
				$arr[$s] = $resultreply;
				$qryreply= mysql_query("select *,DATE(message_date) AS message_date, TIME(message_date) AS message_time from tblmessages where replyid='".$resultreply['id']."'") or die("all:".mysql_error());
			}while(mysql_num_rows($qryreply)>0);

			$mdate = '';
			$html = '';
			foreach($arr as $chat)
			{
				$cdate = date("F d", strtotime($chat['message_date']));
				if($mdate == '' || $mdate != $cdate)
				{
					if($mdate != $cdate && $mdate !='')
					{
						$html .= '<li class="timestamps"><abbr data-utime="0" class="timestamp" data-jsid="timestamp">'.$mdate.'</abbr></li>';
					}
						$mdate = $cdate;
				}	
				if($chat['fromtype']== 'mentor')
				{
					$studentid = $chat['tomember'];
					$fromuser = $this->RetriveMentorFromID($chat['frommember']);
					$user = mysql_fetch_assoc($fromuser);
					$imgpath = "mentor/".$user['picture'];
				}else
				{
					$studentid = $chat['frommember'];
					$fromuser = $this->RetriveStudentByID($chat['frommember']);
					$user = mysql_fetch_assoc($fromuser);
					$imgpath = "student/".$user['picture'];
				}
					$html .= '<li class="in">
						<img class="avatar" alt="" src="../assets/img/'.$imgpath.'" />
						<div class="message">
						<a href="#" class="name">'.$user['fullname'].'</a>
							<span class="datetime">'.date("g:i a", strtotime($chat['message_time'])).'</span>
							<span class="body">'.
							$chat['message']
							.'</span>
						</div>
					</li>';
			}
	
			return $html;
		}
		
	}

	function collectinfoForAdmin(&$loginvarad)
	{
		$loginvarad['username_field'] = $_POST['username_field'];
		$loginvarad['password_field'] = $_POST['password_field'];
	}
	
	function checkAdmin(&$loginvarad)
	{
		$adminname = $loginvarad['username_field'];
		$adminpwd = $loginvarad['password_field'];
		$qryadm = "Select * from $this->tablenameadmin as a where a.username='$adminname' and a.password='$adminpwd'";       

			if(!mysql_query($qryadm))
			{
				$this->HandleError("The username or password does not match");
				return false;
			}
			$resadmin = mysql_query($qryadm);
			$rowsadm = mysql_num_rows($resadmin);
			if(!$rowsadm)
			{
				$this->HandleError("The username or password does not match");
				return false;
			}
			$_SESSION['username']  = $loginvarad['username_field'];
			return true;		
	}
	function get_file_extension($file_name) {
		return end(explode('.',$file_name));
	}


	
	
	function logoutAdmin()
	{
		session_start();
		
		unset ($_SESSION['username']);
		
		unset ($_SESSION['password']);

		session_destroy();
		
		header("location: ../admin");
	
	}
	function StartTest($id,$testid)
	{
		$date_c = date("Y-m-d");
//		$cdate = date("Y-m-d", strtotime($notes_date1));
		$sub = mysql_query("update tblstudenttest set taken_on = '$date_c' where testid='$testid' and studentid='$id'");
	}

	function SubmitAnswers($id)
	{

		$testid = $_POST['testid'];
		$inviteid =  $_POST['inviteid'];
		$q = mysql_query("select * from tbljobinvitation as ji INNER JOIN tblopening as o ON ji.jobid = o.id where ji.id='$inviteid'");

		$invitdet = mysql_fetch_assoc($q);
		$testquest = $this->RetriveTestQuestions($testid);	
		while($question = mysql_fetch_assoc($testquest)){
			$questionid = $question['id'];
			$ans = $_POST['seq'.$questionid];
			$qtype = $question['questiontype'];
			if($qtype=='Multiple Response')
			{
				$arr = array();
				$k=0;
				foreach($ans as $choice)
				{
					$k++;
					$arr[$k] = $choice;
					
				}
				$arrs = implode(",",$arr);
				$sub = "insert into tblstudentanswer(studentid, questionid, answer) values('$id','$questionid','$arrs')";
				$subj = mysql_query($sub);
			}
			else
			{
				$sub = "insert into tblstudentanswer(studentid, questionid, answer) values('$id','$questionid','$ans')";
				$subj = mysql_query($sub);
			}
		}
		
		$s = mysql_query("update tbljobinvitation set status='Submitted Questionnaire',if_read='1' where id='$inviteid'");
		if($this->getTestScore($testid, $id)>100)
		{
			$tod_date = date("Y-m-d");
			$empid = $invitdet['job_by_id'];
			$s = mysql_query("insert into tblemployerfeeds(employerid,feed, feed_date,inviteid) values('$id','Applied','$tod_date','$inviteid')");
		}
		return 'true';

	}
	function getTestScore($testid,$userid)
	{
		$sub = "select *,ttq.id as questionid from tbltestquestion as ttq INNER JOIN tblstudentanswer as tsa ON ttq.id = tsa.questionid where tsa.studentid='$userid' and testid='$testid'";

		$subj = mysql_query($sub);	
		
		$point = 0;
		while($qu = mysql_fetch_assoc($subj))
		{
			$student_answer = $qu['answer'];
			$st_answers = explode(",",$student_answer);
			$questionid = $qu['questionid'];

			if($qu['question_type']=='Multiple Response')
			{

				$sub1 = "select * from tblquestionanswer as tqa where tqa.questionid='$questionid' and is_answer='1'";
				$answers = mysql_query($sub1);	
				$k = 0;
				$is_right = true;
				$num_ans = mysql_num_rows($answers);
				$num_ans_stud = count($st_answers);
				if($num_ans == $num_ans_stud)
				{
					while($answer = mysql_fetch_assoc($answers))
					{
						
							$curr_answer = $answer['answer'];
							if(!in_array($curr_answer,$st_answers))
							{
								$is_right = false;
								break;
							}
						
					}
				}
				if($is_right)
				{
					$point+= $qu['points'];
				}
			} else if($qu['question_type']=='Range')
			{

				$sub1 = "select * from tblquestionanswer as tqa where tqa.questionid='$questionid'";
				$answers = mysql_query($sub1);	
				$k = 0;
				$is_right = true;
				$num_ans = mysql_num_rows($answers);
				$num_ans_stud = count($st_answers);
				$answer = mysql_fetch_assoc($answers);
				$low = $answer['answer'];
				$answer = mysql_fetch_assoc($answers);
				$high = $answer['answer'];
				if($low < $high)
				{
					if($student_answer>$low  && $student_answer<$high)
					{
						$point+= $qu['points'];
					}
				} else if($low > $high)
				{
					if($student_answer<$low  && $student_answer>$high)
					{
						$point+= $qu['points'];
					}
				}
			}
			else
			{
				$sub1 = "select * from tblquestionanswer as tqa where tqa.questionid='$questionid' and is_answer='1'";
				$answers = mysql_query($sub1);	
				while($answer = mysql_fetch_assoc($answers))
				{
					if($answer['is_answer']==1)
					{
						$curr_answer = $answer['answer'];
						if($student_answer == $curr_answer)
						{
							$point+= $qu['points'];
						}
					}
				}
			}
		}
		return $point;
	}

	function addTodo($id,$reftype)
	{
		$task = $_POST['task'];
		$notes_date1 = $_POST['notes_date1'];
		$is_featured = $_POST['is_featured'];
		$date_c = date("Y-m-d");
		$cdate = date("Y-m-d", strtotime($notes_date1));
		$sub = "insert into tbltodo(refid, reftype, title, note_date, created_date, is_featured, is_completed) values('$id','$reftype','$task','$cdate','$date_c','$is_featured','0')";
		$subj = mysql_query($sub);	
		return 'true';
	}
	function getTodoRemaining($id,$reftype)
	{
		$task = $_POST['task'];
		$date_c = date("Y-m-d");
		$sub = "select * from tbltodo where refid='$id' and reftype='$reftype' and is_completed ='0'";
		$subj = mysql_query($sub);	
		if(!mysql_num_rows($subj))
		{	
			//$this->RedirectToUrl("index.php");
		}	
		return $subj;
	
		return 'true';
	}
	function getTodoCompleted($id,$reftype)
	{
		$task = $_POST['task'];
		$date_c = date("Y-m-d");
		$sub = "select * from tbltodo where refid='$id' and reftype='$reftype' and is_completed ='1'";
		$subj = mysql_query($sub);	
		if(!mysql_num_rows($subj))
		{	
			//$this->RedirectToUrl("index.php");
		}	
		return $subj;
	
		return 'true';
	}

	function GetBookedHour()
	{
		$userid = $_SESSION['userid'];
		$sub = "select booked_consultation_hours from tblstudentmentor where studentid='$userid'";
		$subj = mysql_query($sub);	
		$booked = mysql_fetch_assoc($subj);
		$sub = "select sum(additional_hour) as additional_hours from tblstudentadditionalhour where studentid='$userid'";
		$subj = mysql_query($sub);	
		$booked1 = mysql_fetch_assoc($subj);
		$booked_consultation_hours = $booked['booked_consultation_hours'] + $booked1['additional_hours'];
		return $booked_consultation_hours;


	}
	function RetriveMentorFromID($id)
	{
		$sub = "select * from ".$this->tablenamementor." as m where m.id = '$id'";
		
		$subj = mysql_query($sub);
		if(!mysql_num_rows($subj))
		{	
			//$this->RedirectToUrl("index.php");
		}		
		return $subj;
	}
	function RetriveFoldersForMentor($id)
	{
		$sub = "select * from tblmentorfolder as s where mentorid=".$id." ORDER BY createddate desc";		
		
		$subj = mysql_query($sub);
		
		if(!mysql_num_rows($subj))
		{	
			return false;
		}		
		return $subj;
	}
	function RetriveTestForMentor($id)
	{
		$sub = "select * from tbltest as s where mentorid=".$id." ORDER BY created_date desc";		
		
		$subj = mysql_query($sub);
		
		if(!mysql_num_rows($subj))
		{	
			return false;
		}		
		return $subj;
	}
	function RetriveTestForReview($id)
	{

		$sub = "select * from tbltest as tt INNER JOIN tblstudenttest as tst ON tst.studentid = tst.studentid and tst.testid = tt.id where tt.mentorid = ".$id." and taken_on is not null and reviewed_on IS NULL";	
		echo $sub;exit;
		$subj = mysql_query($sub);
		if(!mysql_num_rows($subj))
		{	
			return false;
		}		
		return $subj;
	}	
	function RetriveTestForStudent($id,$is_taken)
	{
		if($is_taken=='1')
		{
		$sub = "select *,s.id as testid from tbltest as s INNER JOIN tblstudenttest as tst ON s.id = tst.testid where tst.studentid = ".$id." and taken_on IS NOT NULL ORDER BY assigned_on desc";		
		}
		else
		{
		$sub = "select *,s.id as testid from tbltest as s INNER JOIN tblstudenttest as tst ON s.id = tst.testid where tst.studentid = ".$id." and taken_on IS NULL ORDER BY assigned_on desc";		
		}
		
		$subj = mysql_query($sub);
		
		if(!mysql_num_rows($subj))
		{	
			return false;
		}		
		return $subj;
	}
	function RetriveTestInfo($testid)
	{
		$userid = $_SESSION['userid'];
		$sub = "select * from tbltest as s INNER JOIN tblstudenttest as tst ON s.id = tst.testid where tst.studentid = ".$userid." and s.id='".$testid."' ORDER BY assigned_on desc";		
		$subj = mysql_query($sub);
		
		if(!mysql_num_rows($subj))
		{	
			return false;
		}		
		return $subj;
	}
	function RetriveTestQuestions($testid)
	{
		$userid = $_SESSION['userid'];
		$sub = "select * from tbltest as s INNER JOIN tbltestquestion as tst ON s.id = tst.testid where s.id='".$testid."' ";		
		
		$subj = mysql_query($sub);
		
		if(!mysql_num_rows($subj))
		{	
			return false;
		}		
		return $subj;
	}
	function RetrieveQuestion($questionid)
	{
		$userid = $_SESSION['userid'];
		$sub = "select * from tbltestquestion as s where s.id='".$questionid."' ";		
		
		$subj = mysql_query($sub);
		
		if(!mysql_num_rows($subj))
		{	
			return false;
		}		
		return $subj;
	}
	function RetrieveQuestionAnswers($questionid)
	{
		$userid = $_SESSION['userid'];
		$sub = "select * from tblquestionanswer as tst where tst.questionid = '".$questionid."'";		
		$subj = mysql_query($sub);
		
		if(!mysql_num_rows($subj))
		{	
			return false;
		}		
		return $subj;
	}
	function RetriveStudentForMentor($id,$name)
	{
		if(trim($name)!='')
		{
			$query_append = " and s.fullname LIKE '%$name%'";
		}
		else
		{
			$query_append='';
		}
		$sub = "select *, DATE(registration_date) AS reg_date, TIME(registration_date) AS reg_time from ".$this->tablenamestudents." as s INNER JOIN tblstudentmentor sm ON s.id = sm.studentid where mentorid=".$id.$query_append." ORDER BY reg_date desc";
		
		
		$subj = mysql_query($sub);
		
		if(!mysql_num_rows($subj))
		{	
			return false;
		}		
		return $subj;
	
	}

	function RetriveConsultations($id)
	{
		$today = date("Y-m-d");
		$oneWeekAgo = strtotime ( '-1 week' , strtotime ( $today ) ) ;
		$weekago =  date ( 'Y-m-d' , $oneWeekAgo );
		$sub = "select *, DATE(consultation_date) AS reg_date, TIME(consultation_date) AS reg_time from tblconsultation as c INNER JOIN ".$this->tablenamestudents." as s INNER JOIN tblconsultationsched as tcs ON c.requestid = tcs.id and c.studentid = s.id WHERE tcs.mentorid='$id' and DATE(consultation_date) > '$weekago'";
		
		$subj = mysql_query($sub);
		if(!mysql_num_rows($subj))
		{	
			return false;
		}		
		return $subj;
	}

	function RetriveRequests($id)
	{
		$today = date("Y-m-d");
		$oneWeekAgo = strtotime ( '-1 week' , strtotime ( $today ) ) ;
		$weekago =  date ( 'Y-m-d' , $oneWeekAgo );
		$sub = "select *,c.id as schd_id from tblconsultationsched as c INNER JOIN ".$this->tablenamestudents." as s ON c.studentid = s.id WHERE mentorid='$id'";
		$subj = mysql_query($sub);
		if(!mysql_num_rows($subj))
		{	
			return false;
		}	
		$row1 = array();
		while($row = mysql_fetch_assoc($subj))
		{
			
			$id1 = $row['schd_id'];
			$sub2 =  mysql_query("select * from tblconsultation WHERE requestid='$id1'");
			if(!mysql_num_rows($sub2))
			{
				$row1[] = $row;
			}
		}
		return $row1;
	}

	function RetriveStudentById($id)
	{
		
		$sub = "select * from ".$this->tablenamestudents." as s WHERE s.id='$id'";
		$subj = mysql_query($sub);
		if(!mysql_num_rows($subj))
		{	
			return false;
		}		
		return $subj;
	
	}

	function RetriveMentorBalance($id)
	{
		$sub = "select sum(booked_fees) as sum from ".$this->tablenamestudents." as s INNER JOIN tblstudentmentor sm ON s.id = sm.studentid where mentorid=".$id;				
		$subj = mysql_query($sub);
		if(!mysql_num_rows($subj))
		{	
			return false;
		}		
		$rows = mysql_fetch_array($subj);
		$sub = "select sum(additional_hr_rate) as sum from tblstudentadditionalhour as s INNER JOIN tblstudentmentor sm ON s.studentid = sm.studentid where mentorid=".$id;				
		$subj = mysql_query($sub);
		if(!mysql_num_rows($subj))
		{	
			return false;
		}		
		$rows1 = mysql_fetch_array($subj);
		$totalsum = $rows['sum'] + $rows1['sum'];
		return $totalsum;
	}
	
	function DeleteFromProduct($id)
	{
		
		$results = mysql_query("select * from products where id='$id'");
		$rows = mysql_fetch_array($results);
		
		$del = "DELETE FROM products WHERE id='$id'";
		
		unlink("uploads/$rows[image]");
		mysql_query($del);
	
	}
	
	function DeleteFromCategory($subid)
	{	
		mysql_query("DELETE FROM category WHERE id='$subid'");
		
		return true;
	
	}
	
	function DeleteFromTopic($ti)
	{	
		mysql_query("DELETE FROM $this->topictable WHERE `topic_id`='$ti'");
		
		return true;
	
	}
	
	function RetriveFromDBwithID($idno)
	{
		$packid = "SELECT * FROM products WHERE id='$idno'";
		
		$pack_id = mysql_query($packid);
		
		if(!mysql_num_rows($pack_id))
		{
			return false;
		}		
		return $pack_id;
	
	}
	
	function RetriveFromTOPwithID($tid)
	{
		$topc = "SELECT * FROM $this->topictable WHERE `topic_id`='$tid'";
		
		$topc_id = mysql_query($topc);
		
		if(!mysql_num_rows($topc_id))
		{
			return false;
		}		
		return $topc_id;
	
	}
	
	//search function
	function get_array($input)
		{	
			if(!empty($input)){
			$arr = explode(",",$input);
			return $arr;
			}else{
			return null;
			}
		}
		
	function adv_search()
	{	
		$array = array();
		$join = array();
		$keyword = $this->get_array($_POST['EZ_KEYWORD_ANY']);
		$keyword1 = $this->get_array($_POST['EZ_KEYWORD_ALL']);
		$keyword2 = $this->get_array($_POST['EZ_KEYWORD_EXCLUDE']);
		$stream = $this->get_array($_POST['andstream']);
		$industry = $this->get_array($_POST['andindustry']);
		if($_POST['SRCH_SRCHKEY_IN']!="ER"){
				$resume="resume";
			}else{
				$resume="resume";
			}
		if(count($keyword) > 0)
			$array['EZ_KEYWORD_ANY'] = "resume LIKE '%".implode("%' OR resume LIKE '%",$keyword)."%'"; 
		if(count($keyword1) > 0)
			$array['EZ_KEYWORD_ALL'] = "resume LIKE '%".implode("%' AND resume LIKE '%",$keyword1)."%'"; 
		if(count($keyword2) > 0)
			$array['EZ_KEYWORD_EXCLUDE'] = "resume NOT LIKE '%".implode("%' AND resume NOT LIKE '%",$keyword2)."%'"; 
		if(!empty($_POST['curr_loc']))
			$array['curr_loc'] = "currentloc LIKE '%".$_POST['curr_loc']."%'"; 
		if(!empty($_POST['DESIG']))
			$array['DESIG'] = "resume LIKE '%".$_POST['DESIG']."%'";
		if(!empty($_POST['DESIG']))
			$array['DESIG'] = "resume LIKE '%".$_POST['DESIG']."%'";
		if(!empty($_POST['ugcourse_id']))
			$array['ugcourse_id'] = "resume LIKE '%".$_POST['ugcourse_id']."%'";
		if(!empty($_POST['ugcourse_id']))
			$array['ugcourse_id'] = "resume LIKE '%".$_POST['ugcourse_id']."%'";
		if(!empty($_POST['pgcourse_id']))
			$array['pgcourse_id'] = "resume LIKE '%".$_POST['pgcourse_id']."%'";
		if(!empty($_POST['MIN_EXPYR'])||!empty($_POST['MAX_EXPYR'])){
			$min = $_POST['MIN_EXPYR']*12;
			$max = $_POST['MAX_EXPYR']*12;
			$array['EXPYR'] = "experiencemonth >= '$min' AND experiencemonth <= '$max'";
			}
		if(!empty($_POST['MIN_CTC'])||!empty($_POST['MIN_CTC_THSND'])||!empty($_POST['MAX_CTC'])||!empty($_POST['MAX_CTC_THSND'])){
			$MIN_CTC = $_POST['MIN_CTC']."L";
			$MIN_CTC_THSND = $_POST['MIN_CTC_THSND']*1000;
			$MAX_CTC = $_POST['MAX_CTC']."L";
			$MAX_CTC_THSND = $_POST['MAX_CTC_THSND']*1000;
			$array['EXPYR'] = "csalaryl >= '$MIN_CTC' AND csalaryk >= '$MIN_CTC_THSND' AND csalaryl >= '$MAX_CTC' AND csalaryk >= '$MAX_CTC_THSND'";
			}
		if(count($industry) > 0){
			$array['andindustry'] = "industry LIKE '%".implode("%' AND industry LIKE '%",$industry)."%'"; 
			}
		if(count($stream) > 0){
			$comma_list = "'" .implode("', '",$stream) . "'";
			$join['andstream'] = " INNER JOIN tblcategory ON catname IN ($comma_list) ";
			$array['andstream'] = " catid = function1 or catid = function2";
			}
		$query = implode(" AND ",$array);
		$join = implode("  ",$join);
		//echo "select * from tblemployees ".$join." where ".$query; die;
		$get_query = mysql_query("select * from tblemployees ".$join." where ".$query);
		return $get_query;
	}
	function admin_search(){
		$array = array();
		$join = array();
		///echo $_POST['orskills']; die;
		$andskills = $this->get_array($_POST['andskills']);
		$andstream = $this->get_array($_POST['andstream']);
		$andindustry = $this->get_array($_POST['andindustry']);
		$andlocation = $this->get_array($_POST['andlocation']);
		//print_r ($andskills); die;
		
		$orskills = $this->get_array($_POST['orskills']);
		$orstream = $this->get_array($_POST['orstream']);
		$orindustry = $this->get_array($_POST['orindustry']);
		$orlocation = $this->get_array($_POST['orlocation']);
		
		$excludeskills = $this->get_array($_POST['excludeskills']);
		$excludestream = $this->get_array($_POST['excludestream']);
		$excludeindustry = $this->get_array($_POST['excludeindustry']);
		$excludelocation = $this->get_array($_POST['excludelocation']);
		
		if(count($andskills) > 0)
			$array['andskills'] = "resume LIKE '%".implode("%' AND resume LIKE '%",$andskills)."%'"; 
		if(count($andstream) > 0){
			$comma_list = "'" .implode("', '",$andstream) . "'";
			$join['andstream'] = " INNER JOIN tblcategory ON catname IN ($comma_list) ";
			$array['andstream'] = " catid = function1 or catid = function2";
			}
		if(count($andindustry) > 0)
			$array['andindustry'] = "industry LIKE '%".implode("%' AND resume LIKE '%",$andindustry)."%'"; 
		if(count($andlocation) > 0)
			$array['andlocation'] = "currentloc LIKE '%".implode("%' AND resume LIKE '%",$andlocation)."%'"; 
			
		if(count($orskills) > 0)
			$array['orskills'] = "resume LIKE '%".implode("%' OR resume LIKE '%",$orskills)."%'";
		if(count($orstream) > 0){
			$comma_list = "'" .implode("', '",$orstream) . "'";
			$join['andstream'] = " INNER JOIN tblcategory ON catname IN ($comma_list) ";
			$array['andstream'] = " catid = function1 or catid = function2";
			}
		if(count($orindustry) > 0)
			$array['orindustry'] = "industry LIKE '%".implode("%' OR resume LIKE '%",$orindustry)."%'";
		if(count($orlocation) > 0)
			$array['orlocation'] = "currentloc LIKE '%".implode("%' OR resume LIKE '%",$orlocation)."%'";
		
		if(count($excludeskills) > 0)
			$array['excludeskills'] = "resume NOT LIKE '%".implode("%' AND resume NOT LIKE '%",$excludeskills)."%'"; 
		if(count($excludestream) > 0){
			$comma_list = "'" .implode("', '",$excludestream) . "'";
			$join['andstream'] = " INNER JOIN tblcategory ON catname IN ($comma_list) ";
			$array['andstream'] = " catid = function1 or catid = function2";
			}
		if(count($excludeindustry) > 0)
			$array['excludeindustry'] = "industry NOT LIKE '%".implode("%' AND resume NOT LIKE '%",$excludeindustry)."%'"; 
		if(count($excludelocation) > 0)
			$array['excludelocation'] = "currentloc NOT LIKE '%".implode("%' AND resume NOT LIKE '%",$excludelocation)."%'"; 
		//print_r ($array['andskills']);	die;
		$query = implode(" AND ",$array);
		$join = implode("  ",$join);
		//$join = implode("  ",$join);
		//echo "select * from tblemployees ".$join." where ".$query; die;
		$get_query = mysql_query("select * from tblemployees ".$join." where ".$query);
		return $get_query;
		
	}
	function RetriveEmployee($jobid)
	{
		$qryreply= mysql_query("Select b.*, a.* from tblopening b, tbljobinvitation a where b.id=a.id and a.jobid=".$jobid." ") or die("all:".mysql_error());
		$qryreply= mysql_query("Select b.*, a.* from tblopening b, tbljobinvitation a where b.id=a.id and a.jobid=".$jobid." ") or die("all:".mysql_error());
		return mysql_num_rows($qryreply);
		
	}
	function SendMail($jobid, $userid, $inviteid){
		$to = 'rajiv@careersatcore.com';
		$subject = 	'Accepting Request Of Matching Job Profile';
		$bound_text = 	"test123";
		$bound = 	"--".$bound_text."\r\n";
		$bound_last = 	"--".$bound_text."--\r\n";
		$headers = 	"From: info@careersatcore.com\r\n";
		$headers .= 	"MIME-Version: 1.0\r\n"."Content-Type: multipart/mixed; boundary=".$bound_text."";
									$message = 	"If you can see this MIME then your client doesn't accept MIME types!\r\n".$bound;
									$message .= 	"Content-Type: text/html; charset=\"iso-8859-1\"\r\n"
																."Content-Transfer-Encoding: 7bit\r\n\r\n"
																."Dear Admin,<br> Please find the employee accepting the request of matching the job profile ";
										$query = mysql_query("select * from tblopening where id='$jobid'") or die("all:".mysql_error());
										$result=mysql_fetch_array($query);
										$jd = $result['jobdescription'];
										if(strlen($jd)>200)
										{
											$jdshort = substr(strip_tags($jd),0,100);
										}
										else
										{
												$jdshort = strip_tags($jd);
										}
										
										$message .= '<div class="job_container job-highlight">
									<h4 class="jobtitle color-core pull-left" >'.$result['jobtitle'].'</h4></div>
									<div class="jobdescription"><strong>Job Description :</strong> '.$jdshort.'</div>
									
									<div class="key_skills"><strong>Key Skills :</strong> '.$result['qualification'].'</div>
									<div class="salary_range"><strong>Salary Range :</strong>Rs. '.$result['salaryfroml'].' '.$salaryfromt.' to '.$result['salarytol'].' '.$salarytot.' '.'</div>
									<div class="job_location"><strong>Location :</strong> '.$result['location'].'</div>
									
								</div><div class="no_of_opening"><strong>No. of Openings :</strong> '.$result['no_of_openings'].' | <strong>No. of Matches :</strong> '.count($emp).' | <strong>Shortfall :</strong> '.($result['no_of_openings'] - count($emp));
										$s = mysql_query("update tbljobinvitation set status='Accepted',if_read='1' where id='$inviteid'");
										$update = mysql_query("select * from tblemployees where id='$userid'") or die("all:".mysql_error());
										$employeematch=mysql_fetch_array($update);
										$message .= '<h1> '.$employeematch['fname'].' '.$employeematch['lname'] .'</h1>
													<ul class="unstyled">
													  <li class="location pull-left right_offset"><span class="muted">Location:</span> '.$employeematch['city'].', '.$employeematch['country'] .'</li>';
										if($employeematch['timeframe'] == 'na'){ $tf = ""; } elseif($employeematch['timeframe'] == '1') {$tf = "1 month";} else $tf=$employeematch['timeframe']." months"; 
										if($employeematch['nodays'] == 'na') $td = ""; elseif($employeematch['nodays'] == '1') $td = "1 day"; else $td=$employeematch['nodays']." days"; 
										if($employeematch['timeframe'] == 'na' && $employeematch['nodays'] == 'na') $tf = "Not Specified";
										$message .= '<li class="location"><span class="muted"></span>Timeframe To Join : '.$tf.' '.$td.'</li></ul>';
									
									@mail($to, $subject, $message, $headers);
	}
	function SubmitAnswersSheet($id){
	
	}
	function RetriveTestSheet($testid)
	{
		$userid = $_SESSION['userid'];
		$sub = "select * from tbltestattachment where id=".$testid."";
		//$sub = "select * from tblopening as s INNER JOIN tbltestattachment as tst ON s.id = tst.userid where tst.id='".$testid."' ";		
		
		$subj = mysql_query($sub);
		
		if(!mysql_num_rows($subj))
		{	
			return false;
		}		
		return $subj;
	}

	
	
}
?>