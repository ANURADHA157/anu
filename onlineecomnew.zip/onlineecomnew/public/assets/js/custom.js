function getAlert(Str){
	return confirm(Str);
}
function setValue(fieldName,fieldValue){
	document.getElementById(fieldName).value=fieldValue;
}