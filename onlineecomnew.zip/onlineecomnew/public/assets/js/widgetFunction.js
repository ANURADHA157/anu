$(function() {
$( ".datepicker" ).datepicker({
		showOtherMonths: true
    });
});