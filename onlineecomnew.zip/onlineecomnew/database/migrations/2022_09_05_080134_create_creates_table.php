<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateCreatesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('creates', function (Blueprint $table) {
            $table->id();
            $table->string('jobtitle');
            $table->string('urlkey');
            $table->string('jobdescription');
            $table->string('function1');
            $table->string('function2');
            $table->string('qualification');
            $table->string('stream1');
            $table->string('stream2');
            $table->string('industry');
            $table->string('experienceyr');
            $table->string('experiencemonth');
            $table->string('salaryfroml');
            $table->string('salaryfromt');
            $table->string('salarytol');
            $table->string('salarytot');
            $table->string('joiningtime');
            $table->string('location[]');
            $table->string('no_of_openings[]');
            $table->string('status');
            $table->string('testid');
            $table->string('testfile');
            $table->string('email_to_send');
            $table->string('company_description');
            $table->string('vdo2');

            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('creates');
    }
}
